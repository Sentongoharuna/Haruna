# FIVEMODS 12 — Field Reliability, Recovery, Identity & Readability

## Protected chain

- CameraX/RootEncoder capture and encoding profiles are unchanged.
- CLEAN masters are never opened for writing by FIVEMODS 12.
- BRAND still uses the existing single Media3 overlay pass and reviewed-caption gate.
- Exposure policy, telemetry acquisition, the 850 ms mode handoff, and all five existing camera layouts remain in place.
- FIVEMODS 12 camera information is a screen-only overlay added to the existing `FrameLayout`; it does not resize or reorder the camera controls.

## Implemented

- Fixed-locale `String.format` audit with a source-contract gate, including the unsafe SAFE HOME call sites.
- Eight-item, reasoned preflight: camera, microphone, storage, permissions, GPS, network, battery, and Android thermal state.
- Capture-result preview watchdog. It rebinds only the affected existing session, never during REC, and permanently stops after two consecutive failed restarts.
- Measured storage-time, low-battery, critical-thermal, background/lock, and microphone-route protection. Critical states request the existing recorder to finalize; no recording-quality preference is silently changed.
- Existing bounded 15-second recovery manifests remain non-destructive. Results are labelled RECOVERED, PARTLY RECOVERED, or COULD NOT RECOVER.
- GPS age is reported as STALE when older than two minutes. Network state never fabricates availability.
- RTMPS keeps the local CLEAN backup during network loss and retries with bounded exponential backoff up to 30 seconds.
- Five fixed identities: `MCAM`, `LIVE`, `TIK`, `STAT`, and `INTV`, each paired with its existing mode name, icon label, and existing distinct chrome accent.
- Camera output stems begin with their mode code. CLEAN carries identity through filename, crash-safe manifest, and verified JSON sidecar only.
- BRAND burns `code + existing mode name` through the existing overlay path.
- Real changing values use the existing motion-aware metric animator. UNKNOWN and UNAVAILABLE values are stationary. FULL-only warning emphasis still respects Android's Remove animations setting.
- Ordinary non-camera pages observe their existing numeric text and roll it only when its real value changes. Camera activities are excluded from this global observer; their dedicated lightweight readouts use the existing metric animator.
- FIVEMODS 12 mode-prefixed files and legacy `DEVELOP_UGANDA_` files remain visible in Recent and media-inbox queries.
- Privacy-safe JSON diagnostics export contains preflight states, recovery counts, preview restarts, and error classes only.
- Readability uses 20 sp page titles, 12–13 sp section labels, 16 sp card titles, 13–14 sp descriptions, 14 sp buttons, dark ON cards with accent borders, and a dark-text gold ON pill.
- Non-camera activities receive a status-bar top inset. Immersive camera screens retain their established full-frame behavior.

## Explicit encoder boundary

The CameraX modes' separate BRAND output can receive identity through the existing Media3 overlay pass. The RootEncoder RTMPS network stream exposes no approved identity overlay hook in the current project. FIVEMODS 12 therefore does **not** modify that encoder. Its local RTMPS backup remains CLEAN and carries identity only in the `LIVE_...` filename, recovery manifest, and sidecar. This is shown in the Field Console instead of claiming an unavailable burn-in.

## Validation gates

- `python3 ci/verify_source_contracts.py`
- `gradle :app:assembleDebug :app:assembleDebugAndroidTest`
- `gradle :app:connectedDebugAndroidTest` (emulator/KVM runner)
- Debug-signed APK only.
