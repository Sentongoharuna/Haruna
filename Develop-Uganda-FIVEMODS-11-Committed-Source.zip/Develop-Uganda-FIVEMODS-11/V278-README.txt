develop.uganda V278 PRO CAM — LIVE WORKFLOW HOME

CUMULATIVE BASE: V277 and everything preserved beneath it.

V278 ADDS:
- Live chronological first-page stages: READY → LIGHT → SOUND → FRAME → MOTION → RECORD → SAFETY → REVIEW.
- One prioritized NEXT BEST ACTION driven by the existing detailed workflow state.
- Lively status line tied to real V272 sound, V273 motion, V274 vault, V276 safety and V277 lighting state.
- Shot Memory reference save + current-setup match score. Long-press MEM SAVE clears the reference.
- Direct stage routing to real existing tools; no fake buttons.
- V277 lighting/exposure, V276 safety/recovery, V275 dual settings and all prior director/proxy/story modules remain.

MASTER POLICY: screen-only workflow guidance; original media masters are not modified by V278.
