DEVELOP.UGANDA V275 PRO CAM • CONTROL SURFACE + DUAL SETTINGS

Version: 275.0-control-surface-dual-settings
Version code: 27500

V275 is cumulative. It starts from the complete V274 source and preserves V271 Output Master + Live Coach, V272 Field Sound + Continuity, V273 Motion + Shot Control, V274 Media Vault + Delivery, V269 Story Desk, V262–V265 director/multicam/proxy systems, LUTS, ASPECT, temporary edge rulers and the established develop.uganda camera interface.

V275 additions:
• Major first-page Control Surface with live readiness, current project/profile, chronological stage rail, contextual next action, quick LUTS/ASPECT/OUTPUT/LAST CLIP/DIRECTOR routes and recent activity.
• Two top Settings routes: CAMERA SETTINGS and WORKFLOW SETTINGS.
• CAMERA SETTINGS groups output master, Live Coach, audio, continuity, motion, media safety and quick profiles. Full legacy Pro Settings remain available and can be opened directly.
• WORKFLOW SETTINGS groups first-page behavior, guidance level, story/media organization and accessibility/control feel.
• Strong ON/OFF visual language: active rows receive a highlighted border/fill and active switches use brighter gold/cyan treatment. OFF is intentionally quiet.
• Existing cumulative Pro Settings moving switches are upgraded with stronger active-state highlighting rather than replaced.
• Quick profiles INTERVIEW / NEWS / NIGHT / SOCIAL / CINEMA preview the exact settings before APPLY. CUSTOM changes nothing.
• First-page LUTS and ASPECT quick actions deep-link to the existing real camera controls.
• Function audit now includes V274 Media Vault plus both V275 Settings activities.

Safety/principles:
• No earlier source file is deleted.
• Original masters are never overwritten by V275 UI changes.
• Clean Master remains clean unless the operator deliberately chooses Reporter/Branded output.
• Hardware/device limitations remain reported truthfully.
