package com.sentongoharuna.pulse

import android.app.Application
import android.content.Context
import android.graphics.Rect
import android.view.MotionEvent
import android.view.TouchDelegate
import android.view.ViewPropertyAnimator
import android.view.View
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import android.view.animation.Interpolator
import android.widget.TextView
import androidx.annotation.ColorInt
import androidx.annotation.ColorRes
import androidx.core.graphics.ColorUtils

/**
 * FIVEMODS 8 XML-only resource reader.
 *
 * Values live once in res/values/develop_uganda_theme.xml. Kotlin contains no
 * ARGB literals or token values: it only reads the requested XML resource.
 */
object DevelopUgandaFivemods8Theme {
    private lateinit var applicationContext: Context

    fun install(context: Context) {
        applicationContext = context.applicationContext
    }

    @ColorInt
    fun color(@ColorRes resourceId: Int): Int =
        applicationContext.getColor(resourceId)

    @get:ColorInt val surface: Int get() = color(R.color.du_surface)
    @get:ColorInt val surfaceRaised: Int get() = color(R.color.du_surface_raised)
    @get:ColorInt val content: Int get() = color(R.color.du_content)
    @get:ColorInt val contentDim: Int get() = color(R.color.du_content_dim)
    @get:ColorInt val accent: Int get() = color(R.color.du_accent)
    @get:ColorInt val modeMain: Int get() = color(R.color.du_mode_main)
    @get:ColorInt val modeLive: Int get() = color(R.color.du_mode_live)
    @get:ColorInt val modeTikTok: Int get() = color(R.color.du_mode_tiktok)
    @get:ColorInt val modeStatus: Int get() = color(R.color.du_mode_status)
    @get:ColorInt val modeInterview: Int get() = color(R.color.du_mode_interview)
    @get:ColorInt val outline: Int get() = color(R.color.du_outline)
    @get:ColorInt val record: Int get() = color(R.color.du_record)
    @get:ColorInt val warning: Int get() = color(R.color.du_warning)
    @get:ColorInt val systemChrome: Int get() = color(R.color.du_system_chrome)
    @get:ColorInt val transparent: Int get() = color(R.color.du_transparent)

    val spacingUnitPx: Int get() = applicationContext.resources.getDimensionPixelSize(R.dimen.du_spacing_unit)
    val touchMinimumPx: Int get() = applicationContext.resources.getDimensionPixelSize(R.dimen.du_touch_minimum)
    val radiusPx: Int get() = applicationContext.resources.getDimensionPixelSize(R.dimen.du_radius)
    val motionDurationMs: Long
        get() = applicationContext.resources.getInteger(R.integer.du_motion_fast_out_slow_in_duration).toLong()

    fun motionInterpolator(context: Context): Interpolator =
        AnimationUtils.loadInterpolator(context, R.interpolator.du_motion_fast_out_slow_in)

    fun typeStyleFor(requestedSp: Float): Int = listOf(
        11f to R.style.du_type_11,
        13f to R.style.du_type_13,
        16f to R.style.du_type_16,
        22f to R.style.du_type_22,
        40f to R.style.du_type_40,
    ).minBy { (step, _) -> kotlin.math.abs(requestedSp - step) }.second

    fun applyTypeScale(view: TextView, requestedSp: Float) {
        view.setTextAppearance(typeStyleFor(requestedSp))
    }

    fun spacingPx(requestedDp: Int): Int {
        if (requestedDp == 0) return 0
        val units = kotlin.math.max(1, kotlin.math.round(requestedDp / 8f).toInt())
        return spacingUnitPx * units
    }

    fun enforceTouchTargets(root: View) {
        if (root.isClickable || root.isLongClickable) {
            expandTouchTarget(root)
        }
        if (root is ViewGroup) {
            for (index in 0 until root.childCount) enforceTouchTargets(root.getChildAt(index))
        }
    }

    /** Keeps the drawn control unchanged while expanding only its hit region. */
    fun expandTouchTarget(view: View) {
        view.post {
            val parent = view.parent as? View ?: return@post
            val bounds = Rect()
            view.getHitRect(bounds)
            val horizontal = maxOf(0, touchMinimumPx - bounds.width())
            val vertical = maxOf(0, touchMinimumPx - bounds.height())
            if (horizontal == 0 && vertical == 0) return@post
            bounds.left -= horizontal / 2
            bounds.right += horizontal - horizontal / 2
            bounds.top -= vertical / 2
            bounds.bottom += vertical - vertical / 2
            val group = (parent.touchDelegate as? DevelopUgandaTouchDelegateGroup)
                ?: DevelopUgandaTouchDelegateGroup(parent).also { parent.touchDelegate = it }
            group.add(bounds, view)
        }
    }

    /*
     * Compatibility alpha composition only. It derives opacity from XML
     * colours and does not introduce another palette or token definition.
     */
    @ColorInt fun surfaceScrim(alpha: Int): Int = ColorUtils.setAlphaComponent(surface, alpha)
    @ColorInt fun raisedScrim(alpha: Int): Int = ColorUtils.setAlphaComponent(surfaceRaised, alpha)
    @ColorInt fun contentScrim(alpha: Int): Int = ColorUtils.setAlphaComponent(content, alpha)
    @ColorInt fun contentDimScrim(alpha: Int): Int = ColorUtils.setAlphaComponent(contentDim, alpha)
    @ColorInt fun accentScrim(alpha: Int): Int = ColorUtils.setAlphaComponent(accent, alpha)
    @ColorInt fun outlineScrim(alpha: Int): Int = ColorUtils.setAlphaComponent(outline, alpha)
    @ColorInt fun recordScrim(alpha: Int): Int = ColorUtils.setAlphaComponent(record, alpha)
    @ColorInt fun warningScrim(alpha: Int): Int = ColorUtils.setAlphaComponent(warning, alpha)
}

private class DevelopUgandaTouchDelegateGroup(parent: View) : TouchDelegate(Rect(), parent) {
    private val delegates = mutableListOf<TouchDelegate>()

    fun add(bounds: Rect, target: View) {
        delegates.removeAll { (it as? TaggedTouchDelegate)?.target === target }
        delegates += TaggedTouchDelegate(Rect(bounds), target)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        for (delegate in delegates) if (delegate.onTouchEvent(event)) return true
        return false
    }

    private class TaggedTouchDelegate(bounds: Rect, val target: View) : TouchDelegate(bounds, target)
}

fun ViewPropertyAnimator.useDevelopUgandaMotion(context: Context): ViewPropertyAnimator =
    setDuration(DevelopUgandaFivemods8Theme.motionDurationMs)
        .setInterpolator(DevelopUgandaFivemods8Theme.motionInterpolator(context))

/** Installs the XML resource reader before any activity creates a view. */
class DevelopUgandaFivemods8Application : Application() {
    override fun onCreate() {
        super.onCreate()
        DevelopUgandaFivemods8Theme.install(this)
    }
}
