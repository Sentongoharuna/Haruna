# FIVEMODS committed-source baseline

The FIVEMODS 10 reconstruction chain was replayed once and the resulting tree
was committed as ordinary source files. The replayed tree contained 103 files.

`baseline/FIVEMODS10-SOURCE-SHA256.txt` records every baseline file hash.
`baseline/COMMITTED-SOURCE-EQUIVALENCE.json` records the independent rebuild:
all 103 source hashes matched and the debug APK was byte-for-byte identical.

All later work is represented by normal commits and normal diffs. The active
workflow builds `:app:assembleDebug` directly from the repository and runs the
preserved camera, caption, CLEAN/BRAND, mode, and button contracts first.

