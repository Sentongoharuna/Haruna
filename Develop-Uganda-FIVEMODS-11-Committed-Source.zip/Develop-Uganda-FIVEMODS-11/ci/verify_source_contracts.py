#!/usr/bin/env python3
"""Source-contract gate carried forward from the verified FIVEMODS 10 chain."""

from __future__ import annotations

import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
PACKAGE = ROOT / "app/src/main/java/com/sentongoharuna/pulse"
EVIDENCE = ROOT / "build/verification"


def need(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(f"SOURCE CONTRACT FAILED: {message}")


def read(name: str) -> str:
    path = PACKAGE / name
    need(path.is_file(), f"required source missing: {name}")
    return path.read_text(encoding="utf-8")


def selected(text: str, start: str, end: str, label: str) -> str:
    need(text.count(start) == 1, f"{label} start anchor changed")
    need(text.count(end) == 1, f"{label} end anchor changed")
    begin = text.index(start)
    return text[begin : text.index(end, begin)]


camera = read("DevelopUgandaCameraActivity.kt")

# The original protected construction block contains 1/4/1. Two later,
# separately protected state updates bring the complete-file inventory to
# 2/4/2. Checking both catches a moved, added, or removed preview scrim.
camera_ui = selected(
    camera,
    "    private fun buildUi() {",
    "\n    private fun requestPermissionsAndStart()",
    "camera UI",
)
for alpha, expected in {38: 1, 66: 4, 82: 1}.items():
    found = camera_ui.count(f"DevelopUgandaFivemods8Theme.surfaceScrim({alpha})")
    need(found == expected, f"camera UI surfaceScrim({alpha}) {found} != {expected}")
for alpha, expected in {38: 2, 66: 4, 82: 2}.items():
    found = camera.count(f"DevelopUgandaFivemods8Theme.surfaceScrim({alpha})")
    need(found == expected, f"whole-file surfaceScrim({alpha}) {found} != {expected}")
need(
    "du_viewfinder_indicator_backing" not in camera,
    "opaque viewfinder backing token reached CameraActivity",
)

exposure = selected(
    camera,
    "    // FIVEMODS 10: the phone's ambient-light sensor",
    "\n    private fun f9UpdateAudioTelemetry(",
    "FIVEMODS 10 exposure",
)
need("ambientLux" not in exposure and "requestedEv" not in exposure,
     "ambient-light exposure override returned")
need("sceneExposureTarget.coerceIn(" in exposure,
     "operator/neutral AE policy changed")
need(exposure.count("setExposureCompensationIndex(requestedIndex)") == 1,
     "exposure write inventory changed")

controls = selected(
    camera,
    "    private fun v244ApplyCamera2Controls(): String {",
    "\n    internal fun v244CycleShutterAngle(): String {",
    "Camera2 controls",
)
need(controls.count("CaptureRequest.CONTROL_AE_MODE_OFF") == 1,
     "manual exposure branch changed")
need(controls.count("CaptureRequest.CONTROL_AE_MODE_ON") == 1,
     "automatic exposure branch changed")
need(controls.count("CaptureRequest.CONTROL_AE_LOCK,\n                        false") == 1,
     "Interview AE unlock changed")
need(camera.count("f9InterviewFrameRateRange") == 3,
     "Interview FPS helper inventory changed")

navigator = read("DevelopUgandaCameraModeNavigator.kt")
for anchor in (
    "CAMERA_HANDOFF_SETTLE_MS = 850L",
    "releaseCamera()",
    "outer.postDelayed(",
    "DevelopUgandaCameraModeRoutes.launch(activity, destination)",
):
    need(navigator.count(anchor) == 1, f"release handoff changed: {anchor}")

profiles = read("DevelopUgandaModeProfiles.kt")
need(
    re.search(
        r"navigatorOrder\s*=\s*listOf\(\s*main\s*,\s*live\s*,\s*tikTok\s*,\s*status\s*,\s*interview\s*\)",
        profiles,
    ) is not None,
    "five-mode navigator order changed",
)
need(profiles.count("stages = listOf(") == 5, "per-mode stage lists missing")
need(profiles.count("profileData = DevelopUgandaModeDataAvailability.ABSENT") == 2,
     "MAIN/LIVE ABSENT contract changed")
need(profiles.count("DevelopUgandaStageAvailability.ABSENT") == 10,
     "MAIN/LIVE stage shells must remain explicitly ABSENT")
for required in ("STREAM_KEY", "CONNECTION", "SEGMENT", "SHARE", "SUBJECT_LOCK", "MARKERS"):
    need(f'"{required}"' in profiles, f"per-mode stage missing: {required}")

presentation = read("DevelopUgandaBroadcastPresentation.kt")
need("enum class DevelopUgandaButtonWeight" in presentation,
     "shared button system missing")
for state in ("PRIMARY", "SECONDARY", "TERTIARY", "DESTRUCTIVE"):
    need(state in presentation, f"button weight missing: {state}")
need("useDevelopUgandaMotion" in presentation and "systemReduceMotion" in presentation,
     "shared motion/reduce-motion routing missing")

readout = read("DevelopUgandaLiveReadout.kt")
for anchor in (
    "DevelopUgandaRollingMetricBuffer",
    "60_000L",
    "DevelopUgandaMetricTrendView",
    "DevelopUgandaMotionLevel",
    "OFF",
    "STANDARD",
    "FULL",
):
    need(anchor in readout, f"metric/motion component missing: {anchor}")
need("TRANSITION_ANIMATION_SCALE" in readout,
     "system reduce-motion setting is not respected")

chrome = read("DevelopUgandaBroadcastCameraChrome.kt")
for anchor in (
    "MODE", "FORMAT", "CODEC", "TC", "BAT", "FREE", "AUDIO",
    "ACTION SAFE", "TITLE SAFE", "CLEAN", "HOLD UNLOCK",
    "left_handed", "dark_adapt", "screen_dim", "OrientationEventListener",
):
    need(anchor in chrome, f"camera chrome capability missing: {anchor}")
need("Handler(" not in chrome and "postDelayed(" not in chrome,
     "camera chrome introduced a timer")
need(re.search(r"0x[0-9A-Fa-f]{6,8}|#[0-9A-Fa-f]{6,8}", chrome) is None,
     "camera chrome introduced a colour literal")
need("DevelopUgandaBroadcastCameraChrome.attach(" in camera,
     "shared chrome is detached from CameraActivity")
need("DevelopUgandaBroadcastCameraChrome.attach(" in read("DevelopUgandaLiveActivity.kt"),
     "shared chrome is detached from LiveActivity")

motion = read("DevelopUgandaV273MotionShotControl.kt")
need("color = DevelopUgandaFivemods8Theme.outline" in motion,
     "motion guide lines no longer use outline")
need("color = DevelopUgandaFivemods8Theme.accent" in motion,
     "motion guide centre no longer uses accent")

captions = read("DevelopUgandaReviewedCaptions.kt")
engine = read("DevelopUgandaTranscriptEngine.kt")
for anchor in (
    "DRAFT_REVIEW_REQUIRED", "CONFIRMED_UNTIMED", "caption_burn_allowed",
    "DevelopUgandaReviewedCaptionOverlay", "WORD CONFIDENCE UNAVAILABLE",
    "PACE", "PAUSE", "seal_scope",
):
    need(anchor.lower() in captions.lower(), f"reviewed caption contract missing: {anchor}")
need("No cloud recognizer was substituted" in engine,
     "on-device-only recognizer honesty contract missing")

exporter = read("DevelopUgandaFivemods9DualOutputExporter.kt")
need("overlays += DevelopUgandaReviewedCaptionOverlay(cues)" in exporter,
     "reviewed captions left the BRAND overlay chain")
need("prepareReviewedCaptions" in exporter and "DevelopUgandaCaptionReview.prepare" in exporter,
     "mandatory review gate missing")
for contract in (
    "clean.videoSamples != brand.videoSamples",
    "Timeline origin differs",
    "Frame timestamp sequence differs",
    "CLEAN SAVED • BRAND MISSING",
):
    need(contract in exporter, f"CLEAN/BRAND contract changed: {contract}")

# These are the 17 restored feature modules whose loadability is also checked
# by the instrumented suite. The source gate protects their ordinary files.
feature_files = (
    "DevelopUgandaV255ProMonitorView.kt",
    "DevelopUgandaV262RemoteDirector.kt",
    "DevelopUgandaV263MultiCamDirector.kt",
    "DevelopUgandaV264LiveCutDirector.kt",
    "DevelopUgandaV265ProxySyncReview.kt",
    "DevelopUgandaV269SmartStoryDesk.kt",
    "DevelopUgandaV270Guidance.kt",
    "DevelopUgandaV271LiveCoach.kt",
    "DevelopUgandaV272FieldSoundContinuity.kt",
    "DevelopUgandaV273MotionShotControl.kt",
    "DevelopUgandaV274MediaVault.kt",
    "DevelopUgandaV275ControlSurface.kt",
    "DevelopUgandaV276RecordingSafety.kt",
    "DevelopUgandaV277LightingExposure.kt",
    "DevelopUgandaV278LiveWorkflow.kt",
    "DevelopUgandaV279ActiveShooting.kt",
    "DevelopUgandaV280SmartDirector.kt",
)
for name in feature_files:
    read(name)

runtime_guard = read("DevelopUgandaV28012RuntimeGuard.kt")
need("MAX_UI_FAULTS = 20" in runtime_guard, "fault ring capacity changed")
need("takeLast(MAX_UI_FAULTS - 1) + fault" in runtime_guard,
     "fault collection is no longer capped")

hub = read("DevelopUgandaGeneralHubActivity.kt")
need("STATUS • UNKNOWN • READ FAILED" in hub,
     "failed route read can no longer be distinguished")
flow = selected(
    hub,
    "    private fun buildFlowTrack(): View {",
    "\n    private fun panelBlock(): LinearLayout",
    "mode stage track",
)
need("DevelopUgandaModeProfiles.selected(this)" in flow and ".stages.forEachIndexed" in flow,
     "flow track is no longer driven by the selected mode stages")
need("postDelayed(" not in flow and "LinearInterpolator" not in flow,
     "flow track regained a decorative timer")
console = read("DevelopUgandaV28012ProWorkflowConsole.kt")
need("SnapshotUnavailableException" in console,
     "failed snapshot no longer reports explicit unavailability")
need("readiness = 70" not in console, "synthetic readiness returned")

newsroom = read("DevelopUgandaNewsroomActivity.kt")
need("UNKNOWN MODE" in newsroom or "UNKNOWN" in newsroom,
     "unknown clip state missing")
need("else -> \"REPORT\"" not in newsroom, "clip classifier guesses REPORT")

delivery = read("DevelopUgandaDeliveryQueue.kt")
for anchor in (
    "setPersisted(true)",
    "Content-Range",
    "X-Content-SHA256",
    "CLEAN MASTER NEEDS EXPLICIT UPLOAD CONSENT",
    "DevelopUgandaV276RecordingSafety.isCaptureActive",
    "WIFI_ONLY",
):
    need(anchor in delivery, f"delivery queue contract missing: {anchor}")

rtmps = read("DevelopUgandaRtmpsLiveActivity.kt")
for anchor in (
    "AndroidKeyStore",
    "migrateLegacyPlaintextKey",
    ".remove(\"key\")",
    "setLogs(false)",
    "QueueAwareBitrateAdapter",
    "LOCAL CLEAN BACKUP NOT READY • LIVE REFUSED",
    "startLocalSegment()",
    "startStream(target)",
    "DevelopUgandaCrashSafeTake.SEGMENT_DURATION_MS",
):
    need(anchor in rtmps, f"RTMPS safety contract missing: {anchor}")
need("rtmp://" not in rtmps, "unencrypted RTMP endpoint accepted")

seal = read("DevelopUgandaSealVerification.kt")
for anchor in (
    "MISSING_SIDECAR",
    "NOT_YET_CHECKED",
    "MessageDigest.getInstance(\"SHA-256\")",
    "exportManifest",
):
    need(anchor in seal, f"seal verification contract missing: {anchor}")
need("?: DevelopUgandaSealState.MISSING_SIDECAR" in seal,
     "unknown seal state can default to verified")

crash_safe = read("DevelopUgandaCrashSafeTake.kt")
for anchor in (
    "BOUNDED_SEGMENTED_CAPTURE",
    "PRESERVE_NEVER_OVERWRITE_OR_DELETE",
    "SEGMENT_DURATION_MS = 15_000L",
    "DevelopUgandaFivemods7Mp4FastStart.ensure",
):
    need(anchor in crash_safe, f"crash-safe capture contract missing: {anchor}")

sound = read("DevelopUgandaV272FieldSoundContinuity.kt")
for anchor in (
    "SAFETY_ATTENUATION = 0.25118864f",
    "tanh(normalized * 1.8)",
    "createWiredMonitor",
    "WIND/HANDLING HIGH",
):
    need(anchor in sound, f"field sound safety contract missing: {anchor}")

instrumentation = ROOT / "app/src/androidTest/java/com/sentongoharuna/pulse/DevelopUgandaFiveModeInstrumentation.kt"
need(instrumentation.is_file(), "five-mode device gate missing")
instrumentation_text = instrumentation.read_text(encoding="utf-8")
for anchor in (
    "modeProfilesAreExactlyFiveInNavigatorOrder",
    "modeDestinationsResolveAndLaunch",
    "mainAndLiveProfileDataStayAbsent",
    "sealStateNeverDefaultsToVerified",
    "draftAndUntimedCaptionsCannotBurn",
):
    need(anchor in instrumentation_text, f"device test missing: {anchor}")

EVIDENCE.mkdir(parents=True, exist_ok=True)
report = {
    "result": "PASS",
    "surface_scrim_protected_block": {"38": 1, "66": 4, "82": 1},
    "surface_scrim_complete_file": {"38": 2, "66": 4, "82": 2},
    "feature_module_count": len(feature_files),
    "clean_master_captioned": False,
    "mode_count": 5,
    "main_live_profile_data": "ABSENT",
    "crash_safe_strategy": "BOUNDED_SEGMENTED_CAPTURE",
    "rtmps_key_storage": "ANDROID_KEYSTORE_AES_GCM",
    "delivery_arrival_proof": "SHA-256",
    "device_gate": instrumentation.name,
}
(EVIDENCE / "source-contracts.json").write_text(
    json.dumps(report, indent=2) + "\n", encoding="utf-8"
)
print("PASS: committed-source contracts verified")
