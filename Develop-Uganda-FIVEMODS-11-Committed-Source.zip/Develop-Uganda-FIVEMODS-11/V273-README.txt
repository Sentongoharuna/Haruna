develop.uganda V273 PRO CAM • MOTION + SHOT CONTROL ENGINE

CUMULATIVE BUILD POLICY
V273 starts from the complete V272 source package. Nothing from V272/V271/V270 and earlier cumulative camera work is intentionally removed.

NEW V273 LAYER
- Live screen-only horizon + movement guide using the existing real rotation-vector and motion score.
- Shot move modes: Handheld, Static, Pan, Tilt, Follow, Walking, Push-In, Pull-Out, Orbit, Tripod, Gimbal.
- Existing real ML Kit face tracking + CameraX AF/AE/AWB surfaced as V273 Subject Tracking Lock.
- Existing real Camera2 manual-focus-distance A/B pull surfaced and organized into V273 workflow.
- New timed CameraX zoom ramp with min/max lens clamping.
- New timed exposure-compensation ramp when supported.
- Rehearsal START/END memory and compatible START restore.
- New V273 first-page live strip and chronological workflow.
- Verification Center truthfully separates real/device-limited/not-claimed behavior.

NOT FAKED
The app does not claim it can physically pan/tilt/orbit the phone, invent tracking confidence, or provide stabilization that the active device does not report.

VERSION
versionCode 27300
versionName 273.0-motion-shot-control
