DEVELOP.UGANDA V277 PRO CAM • LIGHTING + EXPOSURE INTELLIGENCE

Version: 277.0-lighting-exposure-intelligence
Version code: 27700

V277 is cumulative. It starts from the full V276 source and keeps the V271 Output Master/Live Coach, V272 Field Sound/Continuity, V273 Motion/Shot Control, V274 Media Vault/Delivery, V275 Control Surface/Dual Settings, V276 Recording Safety/Recovery, LUTS, Director/Multi-Cam, Proxy Sync, Story Desk and the existing camera controls.

V277 additions:
- Screen-only PreviewView luminance sampling; no new CameraX use case and no burn-in to Clean Master.
- Whole-frame mean light level, highlight percentage and shadow percentage.
- Primary-face region exposure guidance using the existing ML Kit normalized face position.
- Tap spot meter tied to the existing tap-to-focus gesture.
- Backlight detection guidance.
- Warm / neutral / cool preview RGB-balance guidance (not a calibrated Kelvin meter).
- Cautious flicker-risk detection from short preview-luminance variation plus 50/60 Hz regional shutter guidance.
- Tap-to-fix routes: METER FACE uses the existing face AE/AWB metering path; PROTECT HIGHLIGHTS moves exposure compensation one supported step lower.
- Dedicated V277 Lighting + Exposure settings page with highlighted ON/OFF controls.
- LIGHT added to the chronological first-page workflow.
- V277 live lighting strip on the first page.

Truthful limitations:
- V277 lighting values are operator guidance from the phone preview, not a calibrated incident/spot light meter.
- Flicker detection is a risk warning, not a laboratory mains-frequency measurement.
- False color uses the existing V255 screen-only monitor.
- Hardware exposure, WB, HDR, FPS and metering capability remains device dependent.
