develop.uganda V274 PRO CAM • MEDIA VAULT + DELIVERY ENGINE

CUMULATIVE BUILD POLICY
V274 starts from the complete V273 source. No V273/V272/V271 retained source file is intentionally removed. Earlier director, proxy, story, LUT/color, camera, clean-master and guided-workflow layers remain in the package.

NEW V274 LAYER
- Media Vault automatically registers successful new CameraX video masters.
- Clip cards: REVIEW / KEEP / BEST / RETAKE / PROTECT MASTER / FRAME GRAB / SHARE / DELETE with confirmation.
- Protected Master Guard prevents silent deletion while a clip is locked.
- Search/filter by clip, project, camera, health, output mode and rating.
- Clip health labels derived from recorded warning history; no invented QC result.
- Delivery presets: ORIGINAL MASTER / TIKTOK 9:16 / REELS 9:16 / YOUTUBE 16:9 / NEWS DESK / WHATSAPP QUICK.
- Delivery Queue stores delivery intent and state.
- ORIGINAL MASTER can be shared immediately through Android's share sheet.
- Social/aspect-changing presets are truthfully marked RENDER REQUIRED until an editor/export renderer creates a new file.
- Frame Grab writes a JPEG into Pictures/develop.uganda/Frames when Android can decode a video frame.
- New first-page V274 live strip shows latest clip, rating/protection, selected preset and queue count.
- Workflow extends to PREPARE → SOUND → CONTINUITY → FRAME → REHEARSE → RECORD → REVIEW → ORGANIZE → EDIT → DELIVER.

MASTER SAFETY
V274 never overwrites the CameraX original in the Media Vault layer. Delete is explicit, protected masters must be unlocked first, and delivery jobs do not claim a rendered file until one exists.

VERSION
versionCode 27400
versionName 274.0-media-vault-delivery-engine
