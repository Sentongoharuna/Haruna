develop.uganda PRO CAM V280 • SMART DIRECTOR MODE

Cumulative on V279. Adds a practical sequence-directing layer to the first page:
- PLAN → FRAME → TRACK → RECORD → RATE → NEXT SHOT
- director presets: GENERAL / NEWS / TIKTOK / PROPERTY / CONSTRUCTION / INTERVIEW / CINEMA
- preset-specific planned shot sequences
- live Coverage meter and completed/planned shot count
- Next Shot guidance with shot-specific capture advice
- automatic single-step progression when Media Vault clip count increases
- manual SHOT DONE fallback
- tap any shot chip to retarget the sequence
- previous/next target navigation
- generated shot-name label based on preset + sequence position + shot type
- missing-shot summary before leaving the scene
- BEST marker routes through preserved V279 Take Intelligence
- Media Vault review + reset controls

V279 Active Shooting Intelligence and the full V271–V278 stack remain preserved.
No unsupported autonomous scene understanding, object tracking, or camera movement is claimed.
