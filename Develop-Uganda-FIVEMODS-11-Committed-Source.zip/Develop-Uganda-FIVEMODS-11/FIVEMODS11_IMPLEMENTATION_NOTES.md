# FIVEMODS 11 implementation record

This repository is the ordinary-source successor to the FIVEMODS 10 patch
chain. Commit `40335cb` is the migration baseline: all 103 source-file hashes
matched the reconstructed tree and the two debug APKs were byte-identical.
Subsequent changes are ordinary Git diffs.

## Decisions where Android could not supply a truthful value

- **Pre-record buffer:** CameraX Recorder does not expose encoded audio/video
  samples or a supported way to prepend them to a new recording. The existing
  preference remains compatible, but the HUD says `NOT YET VERIFIED` and the
  default remains off. No fake armed state is shown and capture ownership was
  not replaced merely to satisfy a label.
- **Social-platform coverage margins:** no versioned, authoritative TikTok or
  WhatsApp overlay geometry is available in the app. The thin guide layer says
  `PLATFORM UI COVERAGE • ABSENT`; it does not guess a safe margin.
- **MAIN/LIVE profile data:** both remain `ABSENT`; their stage shells are
  visible and explicitly `ABSENT`. No frame rate, bitrate, readiness, or
  delivery value is fabricated.
- **Storage time:** shown only after the selected mode has a measured bitrate.
  Battery minutes and thermal headroom remain `UNKNOWN` when Android supplies
  no measurement from which they can be calculated.
- **Colour status `94%`:** this was not a measured confidence value. It is the
  operator-selected LUT/profile strength and is now labelled
  `DERIVED • OPERATOR PROFILE SETTING` wherever written.

## Recording protection

CameraX writes a single ordinary MP4 and does not expose a supported periodic
`moov`/sample-table flush. FIVEMODS 11 therefore uses **bounded segmented
capture**: each 15-second CLEAN segment is independently finalised and listed
in a durable take manifest. The current unfinished fragment is preserved and
never overwritten or deleted. On launch, completed segments are verified as
playable; a raw fragment is repaired only into a separate copy using
`DevelopUgandaFivemods7Mp4FastStart` when it already contains sufficient MP4
tables.

The manifest records the real recorder duration, byte count and measured
restart seam for every segment. File-size cost is the measured sum of the
individual containers. Frame cost is represented by the measured restart gap.
Per-take battery cost cannot be isolated by Android and is recorded as
`UNKNOWN_NOT_MEASURABLE_PER_TAKE`, not guessed.

The field-sound companion is a real 48 kHz stereo WAV: limited primary in the
left channel and a -12 dB safety signal in the right. Input routing prioritises
USB, wired, Bluetooth, then the phone mic. Wired/USB headphone monitoring uses
non-blocking writes on the safety-audio worker and never routes to the phone
speaker. If Android refuses concurrent microphone access, the HUD reports the
failure and the CameraX CLEAN recording continues unchanged.

## LIVE implementation

LIVE uses the vendored Apache-2.0 RootEncoder 2.8.1 AARs. It was selected
because it supplies RTMPS, actual sent-bitrate and dropped-frame counters,
queue-aware bitrate adaptation, and simultaneous local MP4 recording. Library
logging is disabled before an endpoint is provided. Stream keys are encrypted
with AES-GCM in Android Keystore, are never displayed after entry, and are
redacted from connection errors. On first use, a legacy plaintext stream key
is migrated only when its endpoint is already RTMPS; the insecure plaintext
copy is then removed. A non-RTMPS legacy key is discarded rather than sent to
an unencrypted destination.

Going live is refused unless a segmented local CLEAN backup starts first.
Congestion lowers the stream from 720p to 540p to 480p while preserving the
completed local segment. A network failure never deletes the local backup.

## Delivery, review, and verification

- The Media Vault queue persists through restarts and boot, defaults to Wi-Fi,
  resumes by acknowledged byte offset or verified 1 MiB chunks, yields to an
  active take, and accepts delivery only after the destination proves the
  whole-file SHA-256.
- A CLEAN item requires explicit consent for that one queue item and is never
  deleted automatically.
- Marks use recorder-reported elapsed durations and are stored in separate
  sidecars. In-app review can seek to marks and confirmed caption cues.
- Seal state starts at `NOT YET CHECKED` or `MISSING SIDECAR`. Only a fresh
  SHA-256 read can produce `VERIFIED`; mismatches are `ALTERED`.

## Motion migration

The single setting is `OFF`, `STANDARD`, or `FULL`, default `STANDARD`.

- any explicitly false `lively_first_page` or `workflow_motion` → `OFF`
- otherwise legacy `workflow_motion_style=NORMAL` → `FULL`
- all other legacy/default combinations → `STANDARD`
- system transition animation scale `0` → runtime `OFF`

Changing the new setting writes compatible values back to all three legacy
keys so existing callers continue to work.

## Build and verification

Run `python3 ci/verify_source_contracts.py`, then
`gradle :app:assembleDebug`. The source gate retains the exact CameraActivity
scrim inventories, the viewfinder-backing prohibition, the FIVEMODS 9/10
exposure and handoff checks, CLEAN/BRAND and reviewed-caption checks, and adds
gates for per-mode stages, crash-safe capture, secure RTMPS, delivery integrity,
field sound, and seal verification. The GitHub workflow also builds and runs
the five-mode instrumented test APK on an emulator.
