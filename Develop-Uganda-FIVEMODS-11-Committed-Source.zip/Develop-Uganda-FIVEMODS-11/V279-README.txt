develop.uganda PRO CAM V279 • ACTIVE SHOOTING INTELLIGENCE

Cumulative on V278. Adds a telemetry-driven first-page shooting intelligence layer:
- READY → LIGHT → SOUND → FRAME → TRACK → RECORD → PROTECT → RATE
- composite Recording Health score/bar
- one prioritized Next Best Action
- Shot Memory continuity drift status
- lighting-category Scene Change watch
- operator Subject Priority and Silent Alert intent controls
- live Take Quality estimate based on available light/audio/safety/readiness/continuity telemetry
- GOOD / RETAKE / B-ROLL / INTERVIEW take tags
- BEST TAKE marker tied to current Media Vault clip count

No unsupported computer-vision tracking is claimed or faked. Existing V271–V278 modules remain preserved.
