# develop.uganda 286.00 — Parts 9–10

Version code: `28600`
Version name: `286.00-parts9-10-detection-camera-craft`

## Delivered

- Interview subject lock now draws tracked, easing detection outlines with tracking ID, lock state, and the measured crop percentage that selects the content/warning/record colour. Secondary faces remain dim and untagged until selected. Empty, failed, disabled, and stale detections clear instead of freezing.
- The optional 11 sp detection-band legend is off by default and can be dismissed directly. Detection drawing remains a screen-only `View`; it has no CameraX or encoder effect.
- One token-only result component now owns measured or explicitly indeterminate progress and success/failure resolution for delivery queue items, seal checks, caption confirmation, recovery, and BRAND export.
- Project-scoped ghost references can come from the live preview or any Media Vault take. Take extraction runs after capture on a worker, writes an app-private take-linked still and `.ghost.json` sidecar, and never opens the source take for writing. Selecting a take explicitly activates it; subsequent recordings do not silently replace it. Opacity choices span 5–50%, with a one-tap rolling control and source/date label.
- The record control has an outline capacity ring driven by measured free storage and the last measured bytes-per-second for the active mode. Missing measurements render `CAP ?` with an unfilled outline.
- The old screen text-only tilt owner is replaced by a screen-only artificial horizon with roll line, pitch reticle, level snap, measured value, and content/warning/record states.
- The editor defaults to a cached thumbnail filmstrip with in/out marks, rolling marks, and confirmed caption cue boundaries. Extraction is off the capture path and never transforms the source.
- LIVE uses the reusable trend renderer for a 30-second actual upload-bitrate bar history. Missing sample time stays blank, adaptive step-downs are marked, and tapping opens up to 12 hours of measured session history.
- Every Part 10 overlay has a remembered per-mode switch. The vectorscope drawing path is removed; the existing V255 waveform remains.
- Night/low-light is a plain record-token chrome change: its preview tint is explicitly transparent, with no glow or reflection treatment.

## Truth and performance boundaries

- Protected camera preview scrims remain exactly `surfaceScrim(38) ×2`, `surfaceScrim(66) ×4`, and `surfaceScrim(82) ×2` in the complete camera source.
- CLEAN never receives detection, ghost, capacity, horizon, filmstrip, or uplink drawing. No new CameraX capture use case or encoder overlay was added.
- Ghost and thumbnail extraction use worker threads. UI overlays draw on the normal view path. Measured values show an explicit unknown/indeterminate state when unavailable.
- Device frame-rate regression was not measured in this container; no zero-FPS-impact claim is made. The CI device suite remains a hard gate and does not permit test failure.

## Verification

- `python3 ci/verify_source_contracts.py` — PASS
- `:app:compileDebugKotlin` — PASS
- `:app:compileDebugAndroidTestKotlin` — PASS
- `:app:testDebugUnitTest` — PASS (`NO-SOURCE` in this project)
- `:app:assembleDebug` — PASS
- `:app:assembleDebugAndroidTest` — PASS
- APK manifest: package `com.sentongoharuna.pulse`, min SDK 23, target/compile SDK 36, version code 28600
- Local emulator execution was unavailable because this SDK image has no `adb`; the API 35 emulator run remains enforced by the checked-in workflow.
