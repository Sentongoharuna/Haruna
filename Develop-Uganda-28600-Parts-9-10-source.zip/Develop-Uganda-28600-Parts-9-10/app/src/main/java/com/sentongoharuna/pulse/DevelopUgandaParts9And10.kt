package com.sentongoharuna.pulse

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.SystemClock
import android.text.TextUtils
import android.util.AttributeSet
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File
import java.io.FileOutputStream
import java.security.MessageDigest
import java.util.Locale
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicLong
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Per-camera-mode ownership for every Part 9/10 screen aid. */
object DevelopUgandaParts9And10Settings {
    private const val PREFS = "develop_uganda_parts_9_10"
    const val DETECTION_BOXES = "detection_boxes"
    const val DETECTION_LEGEND = "detection_legend"
    const val GHOST_FRAME = "ghost_frame"
    const val CAPACITY_RING = "capacity_ring"
    const val ARTIFICIAL_HORIZON = "artificial_horizon"
    const val FILMSTRIP = "filmstrip"
    const val UPLINK_METER = "uplink_meter"

    private fun prefs(context: Context) = context.duSharedPreferences(PREFS, Context.MODE_PRIVATE)
    private fun key(feature: String, page: DevelopUgandaCameraPage) = "${feature}_${page.name}"

    fun markActiveMode(context: Context, page: DevelopUgandaCameraPage) {
        prefs(context).edit().putString("active_mode", page.name).apply()
    }

    fun activeMode(context: Context): DevelopUgandaCameraPage =
        prefs(context).getString("active_mode", DevelopUgandaCameraPage.MAIN.name)
            ?.let { runCatching { DevelopUgandaCameraPage.valueOf(it) }.getOrNull() }
            ?: DevelopUgandaCameraPage.MAIN

    fun enabled(
        context: Context,
        page: DevelopUgandaCameraPage,
        feature: String,
        defaultValue: Boolean,
    ): Boolean = prefs(context).getBoolean(key(feature, page), defaultValue)

    fun setEnabled(
        context: Context,
        page: DevelopUgandaCameraPage,
        feature: String,
        value: Boolean,
    ) {
        prefs(context).edit().putBoolean(key(feature, page), value).apply()
    }

    fun toggle(
        context: Context,
        page: DevelopUgandaCameraPage,
        feature: String,
        defaultValue: Boolean,
    ): Boolean {
        val next = !enabled(context, page, feature, defaultValue)
        setEnabled(context, page, feature, next)
        return next
    }

    fun intValue(
        context: Context,
        page: DevelopUgandaCameraPage,
        feature: String,
        defaultValue: Int,
    ): Int = prefs(context).getInt(key(feature, page), defaultValue)

    fun setIntValue(
        context: Context,
        page: DevelopUgandaCameraPage,
        feature: String,
        value: Int,
    ) {
        prefs(context).edit().putInt(key(feature, page), value).apply()
    }
}

enum class DevelopUgandaMeasuredBand {
    NORMAL,
    DEGRADED,
    CRITICAL,
    UNKNOWN;

    fun color(): Int = when (this) {
        NORMAL -> DevelopUgandaFivemods8Theme.content
        DEGRADED -> DevelopUgandaFivemods8Theme.warning
        CRITICAL -> DevelopUgandaFivemods8Theme.record
        UNKNOWN -> DevelopUgandaFivemods8Theme.outline
    }
}

/**
 * The one Part 9 result component. Progress is either a supplied numerator and
 * denominator or is explicitly indeterminate; this view never advances a
 * percentage by time.
 */
class DevelopUgandaResultStateView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : LinearLayout(context, attrs) {
    private val ring = DevelopUgandaResultRingView(context)
    private val state = TextView(context).apply {
        gravity = Gravity.CENTER
        setTextColor(DevelopUgandaFivemods8Theme.content)
        typeface = android.graphics.Typeface.DEFAULT_BOLD
        letterSpacing = 0.14f
        isAllCaps = true
        DevelopUgandaFivemods8Theme.applyTypeScale(this, 11f)
    }
    private val explanation = TextView(context).apply {
        gravity = Gravity.CENTER
        setTextColor(DevelopUgandaFivemods8Theme.contentDim)
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        DevelopUgandaFivemods8Theme.applyTypeScale(this, 13f)
    }

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        setPadding(0, spacing(1), 0, spacing(1))
        addView(
            ring,
            LayoutParams(touch(), touch()),
        )
        addView(state, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        addView(explanation, LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        contentDescription = "Result state"
    }

    fun setPending(stateLabel: String, detail: String) {
        visibility = View.VISIBLE
        ring.setPending()
        state.text = stateLabel.uppercase(Locale.US)
        state.setTextColor(DevelopUgandaFivemods8Theme.contentDim)
        explanation.text = detail
        contentDescription = "${state.text}. $detail"
    }

    fun setWorking(
        completed: Long?,
        total: Long?,
        stateLabel: String,
        detail: String,
    ) {
        visibility = View.VISIBLE
        val measurable = completed != null && total != null && total > 0L
        ring.setWorking(if (measurable) completed!!.toDouble() / total!!.toDouble() else null)
        state.text = if (measurable) {
            val percent = ((completed!!.toDouble() / total!!.toDouble()) * 100.0)
                .coerceIn(0.0, 100.0)
            String.format(Locale.US, "%s • %.0f%%", stateLabel.uppercase(Locale.US), percent)
        } else {
            "${stateLabel.uppercase(Locale.US)} • INDETERMINATE"
        }
        state.setTextColor(DevelopUgandaFivemods8Theme.content)
        explanation.text = detail
        contentDescription = "${state.text}. $detail"
    }

    fun setSuccess(stateLabel: String, detail: String) = resolve(true, stateLabel, detail)

    fun setFailure(stateLabel: String, detail: String) = resolve(false, stateLabel, detail)

    private fun resolve(success: Boolean, stateLabel: String, detail: String) {
        visibility = View.VISIBLE
        ring.resolve(success)
        state.text = stateLabel.uppercase(Locale.US)
        state.setTextColor(
            if (success) DevelopUgandaFivemods8Theme.accent
            else DevelopUgandaFivemods8Theme.record,
        )
        explanation.text = detail
        contentDescription = "${state.text}. $detail"
    }

    private fun spacing(units: Int) = DevelopUgandaFivemods8Theme.spacingUnitPx * units
    private fun touch() = DevelopUgandaFivemods8Theme.touchMinimumPx
}

private class DevelopUgandaResultRingView(context: Context) : View(context) {
    private enum class Phase { PENDING, WORKING, SUCCESS, FAILURE }

    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = DevelopUgandaFivemods8Theme.outline
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 1.5f
    }
    private val value = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = DevelopUgandaFivemods8Theme.content
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 2f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private var phase = Phase.PENDING
    private var progress: Float? = null
    private var rotationDegrees = -90f
    private var markFraction = 1f
    private var animator: ValueAnimator? = null

    fun setPending() {
        stopAnimation()
        phase = Phase.PENDING
        progress = null
        invalidate()
    }

    fun setWorking(measuredProgress: Double?) {
        phase = Phase.WORKING
        progress = measuredProgress?.toFloat()?.coerceIn(0f, 1f)
        if (progress == null) startIndeterminate() else stopAnimation()
        invalidate()
    }

    fun resolve(success: Boolean) {
        stopAnimation()
        phase = if (success) Phase.SUCCESS else Phase.FAILURE
        progress = 1f
        value.color = if (success) DevelopUgandaFivemods8Theme.accent else DevelopUgandaFivemods8Theme.record
        markFraction = 0f
        if (DevelopUgandaMotionPreferences.animationAllowed(context)) {
            animator = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = DevelopUgandaFivemods8Theme.motionDurationMs
                interpolator = DevelopUgandaFivemods8Theme.motionInterpolator(context)
                addUpdateListener {
                    markFraction = it.animatedValue as Float
                    invalidate()
                }
                start()
            }
        } else {
            markFraction = 1f
            invalidate()
        }
    }

    private fun startIndeterminate() {
        if (animator?.isRunning == true) return
        animator = ValueAnimator.ofFloat(-90f, 270f).apply {
            duration = DevelopUgandaFivemods8Theme.motionDurationMs * 5L
            repeatCount = ValueAnimator.INFINITE
            interpolator = android.view.animation.LinearInterpolator()
            addUpdateListener {
                rotationDegrees = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    private fun stopAnimation() {
        animator?.cancel()
        animator = null
    }

    override fun onDetachedFromWindow() {
        stopAnimation()
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val inset = resources.displayMetrics.density * 5f
        val bounds = RectF(inset, inset, width - inset, height - inset)
        canvas.drawOval(bounds, track)
        when (phase) {
            Phase.PENDING -> Unit
            Phase.WORKING -> {
                value.color = DevelopUgandaFivemods8Theme.content
                val sweep = progress?.let { 360f * it } ?: 82f
                canvas.drawArc(bounds, if (progress == null) rotationDegrees else -90f, sweep, false, value)
            }
            Phase.SUCCESS -> {
                value.color = DevelopUgandaFivemods8Theme.accent
                canvas.drawArc(bounds, -90f, 360f, false, value)
                val path = Path().apply {
                    moveTo(width * 0.27f, height * 0.52f)
                    lineTo(width * 0.44f, height * 0.68f)
                    lineTo(width * 0.74f, height * 0.34f)
                }
                drawPathFraction(canvas, path, markFraction, value)
            }
            Phase.FAILURE -> {
                value.color = DevelopUgandaFivemods8Theme.record
                canvas.drawArc(bounds, -90f, 360f, false, value)
                canvas.drawLine(
                    width * 0.32f,
                    height * 0.32f,
                    width * (0.32f + 0.36f * markFraction),
                    height * (0.32f + 0.36f * markFraction),
                    value,
                )
                canvas.drawLine(
                    width * 0.68f,
                    height * 0.32f,
                    width * (0.68f - 0.36f * markFraction),
                    height * (0.32f + 0.36f * markFraction),
                    value,
                )
            }
        }
    }

    private fun drawPathFraction(canvas: Canvas, source: Path, fraction: Float, paint: Paint) {
        val measure = android.graphics.PathMeasure(source, false)
        val visible = Path()
        measure.getSegment(0f, measure.length * fraction.coerceIn(0f, 1f), visible, true)
        canvas.drawPath(visible, paint)
    }
}

/** Thin screen-only roll line, pitch marker and measured numeric value. */
class DevelopUgandaArtificialHorizonView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density * 1.25f
        strokeCap = Paint.Cap.SQUARE
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = resources.displayMetrics.scaledDensity * 11f
        typeface = android.graphics.Typeface.create(android.graphics.Typeface.MONOSPACE, android.graphics.Typeface.BOLD)
    }
    private var roll: Float? = null
    private var pitch: Float? = null

    fun setMeasurement(rollDegrees: Float?, pitchDegrees: Float?) {
        roll = rollDegrees?.takeIf { it.isFinite() }
        pitch = pitchDegrees?.takeIf { it.isFinite() }
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val measuredRoll = roll
        val centerX = width / 2f
        val centerY = height / 2f
        if (measuredRoll == null) {
            line.color = DevelopUgandaMeasuredBand.UNKNOWN.color()
            text.color = DevelopUgandaFivemods8Theme.contentDim
            canvas.drawLine(width * 0.16f, centerY, width * 0.42f, centerY, line)
            canvas.drawLine(width * 0.58f, centerY, width * 0.84f, centerY, line)
            canvas.drawText("--.-°", width * 0.86f, centerY + text.textSize * 0.35f, text)
            return
        }

        val absolute = abs(measuredRoll)
        val band = when {
            absolute <= 1f -> DevelopUgandaMeasuredBand.NORMAL
            absolute <= 3f -> DevelopUgandaMeasuredBand.DEGRADED
            else -> DevelopUgandaMeasuredBand.CRITICAL
        }
        line.color = band.color()
        text.color = band.color()
        val snappedRoll = if (absolute <= 1f) 0f else measuredRoll.coerceIn(-24f, 24f)
        val pitchOffset = (pitch ?: 0f).coerceIn(-12f, 12f) * resources.displayMetrics.density * 0.75f

        canvas.save()
        canvas.rotate(-snappedRoll, centerX, centerY)
        canvas.translate(0f, pitchOffset)
        canvas.drawLine(width * 0.12f, centerY, width * 0.44f, centerY, line)
        canvas.drawLine(width * 0.56f, centerY, width * 0.88f, centerY, line)
        canvas.restore()

        // Fixed aircraft-style pitch reticle; the measured horizon moves behind it.
        canvas.drawLine(centerX - width * 0.045f, centerY, centerX + width * 0.045f, centerY, line)
        canvas.drawLine(centerX, centerY - height * 0.16f, centerX, centerY + height * 0.16f, line)
        val value = String.format(Locale.US, "%+.1f°", measuredRoll)
        canvas.drawText(value, width * 0.86f, centerY + text.textSize * 0.35f, text)
        contentDescription = "Horizon ${if (absolute <= 1f) "level" else "roll $value"}"
    }
}

/**
 * Editor filmstrip. Frames are extracted on one worker and cached as stills;
 * the source video is opened read-only and is never transformed or re-encoded.
 */
class DevelopUgandaFilmstripView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {
    private val worker = Executors.newSingleThreadExecutor()
    private val generation = AtomicLong(0L)
    private var frames: List<Bitmap?> = emptyList()
    private var durationMs = 0L
    private var inMs = 0L
    private var outMs = 0L
    private var marks: List<Long> = emptyList()
    private var cues: List<Pair<Long, Long>> = emptyList()
    private var seekListener: ((Long) -> Unit)? = null
    private val outline = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = DevelopUgandaFivemods8Theme.outline
        style = Paint.Style.STROKE
        strokeWidth = resources.displayMetrics.density
    }
    private val inOut = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = DevelopUgandaFivemods8Theme.accent
        strokeWidth = resources.displayMetrics.density * 2f
    }
    private val mark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = DevelopUgandaFivemods8Theme.warning
        strokeWidth = resources.displayMetrics.density * 1.5f
    }
    private val cue = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = DevelopUgandaFivemods8Theme.content
        strokeWidth = resources.displayMetrics.density
    }
    private val placeholder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = DevelopUgandaFivemods8Theme.contentDim
        textSize = resources.displayMetrics.scaledDensity * 11f
    }

    init {
        isClickable = true
        isFocusable = true
        contentDescription = "Filmstrip timeline"
    }

    fun setOnSeekListener(listener: ((Long) -> Unit)?) {
        seekListener = listener
    }

    fun bind(
        uri: Uri,
        displayName: String,
        durationMs: Long,
        inMs: Long,
        outMs: Long,
        marks: List<Long>,
        cues: List<DevelopUgandaCaptionCue>,
    ) {
        val request = generation.incrementAndGet()
        this.durationMs = durationMs.coerceAtLeast(0L)
        this.inMs = inMs.coerceIn(0L, this.durationMs)
        this.outMs = outMs.coerceIn(this.inMs, this.durationMs)
        this.marks = marks.filter { it in 0L..this.durationMs }.distinct().sorted()
        this.cues = cues.mapNotNull {
            val start = it.startMs.coerceIn(0L, this.durationMs)
            val end = it.endMs.coerceIn(0L, this.durationMs)
            (start to end).takeIf { pair -> pair.second > pair.first }
        }
        recycleFrames()
        frames = emptyList()
        invalidate()
        if (this.durationMs <= 0L) return
        worker.execute {
            val loaded = loadFrames(uri, displayName, this.durationMs)
            post {
                if (generation.get() != request) {
                    loaded.filterNotNull().forEach { runCatching { it.recycle() } }
                } else {
                    recycleFrames()
                    frames = loaded
                    invalidate()
                }
            }
        }
    }

    fun setCut(inMs: Long, outMs: Long) {
        this.inMs = inMs.coerceIn(0L, durationMs)
        this.outMs = outMs.coerceIn(this.inMs, durationMs)
        invalidate()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (durationMs <= 0L || width <= 0) return false
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE, MotionEvent.ACTION_UP -> {
                val value = (durationMs * (event.x / width.toFloat()).coerceIn(0f, 1f)).toLong()
                seekListener?.invoke(value)
                if (event.actionMasked == MotionEvent.ACTION_UP) performClick()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    override fun performClick(): Boolean {
        super.performClick()
        return true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val localFrames = frames
        if (localFrames.isEmpty()) {
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), outline)
            canvas.drawText("THUMBNAILS LOADING OFF CAPTURE PATH", 10f, height / 2f, placeholder)
        } else {
            val cellWidth = width.toFloat() / localFrames.size.toFloat()
            localFrames.forEachIndexed { index, bitmap ->
                val destination = RectF(index * cellWidth, 0f, (index + 1) * cellWidth, height.toFloat())
                if (bitmap == null || bitmap.isRecycled) {
                    canvas.drawRect(destination, outline)
                } else {
                    val source = centerCrop(bitmap, destination.width() / destination.height())
                    canvas.drawBitmap(bitmap, source, destination, null)
                }
            }
            canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), outline)
        }
        if (durationMs <= 0L) return
        fun x(timeMs: Long) = width * (timeMs.toFloat() / durationMs.toFloat()).coerceIn(0f, 1f)
        val inX = x(inMs)
        val outX = x(outMs)
        canvas.drawLine(inX, 0f, inX, height.toFloat(), inOut)
        canvas.drawLine(outX, 0f, outX, height.toFloat(), inOut)
        marks.forEach { time ->
            val at = x(time)
            canvas.drawLine(at, height * 0.28f, at, height.toFloat(), mark)
        }
        cues.forEach { (start, end) ->
            canvas.drawLine(x(start), 0f, x(start), height * 0.23f, cue)
            canvas.drawLine(x(end), 0f, x(end), height * 0.23f, cue)
        }
    }

    private fun loadFrames(uri: Uri, displayName: String, duration: Long): List<Bitmap?> {
        val count = 10
        val cache = cacheDirectory(uri, displayName, duration)
        val cached = (0 until count).map { BitmapFactory.decodeFile(File(cache, "$it.jpg").absolutePath) }
        if (cached.all { it != null }) return cached
        cached.filterNotNull().forEach { runCatching { it.recycle() } }
        val retriever = MediaMetadataRetriever()
        return try {
            retriever.setDataSource(context, uri)
            (0 until count).map { index ->
                val atUs = ((duration * index.toLong()) / max(1, count - 1) * 1_000L)
                val source = retriever.getFrameAtTime(atUs, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    ?: return@map null
                val targetWidth = 240
                val targetHeight = max(1, (source.height * (targetWidth.toFloat() / source.width.toFloat())).toInt())
                val scaled = Bitmap.createScaledBitmap(source, targetWidth, targetHeight, true)
                if (scaled !== source) source.recycle()
                runCatching {
                    FileOutputStream(File(cache, "$index.jpg")).use { output ->
                        scaled.compress(Bitmap.CompressFormat.JPEG, 76, output)
                    }
                }
                scaled
            }
        } catch (_: Exception) {
            List(count) { null }
        } finally {
            runCatching { retriever.release() }
        }
    }

    private fun cacheDirectory(uri: Uri, displayName: String, duration: Long): File {
        val digest = MessageDigest.getInstance("SHA-256")
            .digest("${uri}|$displayName|$duration".toByteArray(Charsets.UTF_8))
            .take(12)
            .joinToString("") { "%02x".format(Locale.US, it) }
        return File(context.cacheDir, "develop_uganda_filmstrip/$digest").apply { mkdirs() }
    }

    private fun centerCrop(bitmap: Bitmap, targetRatio: Float): Rect {
        val sourceRatio = bitmap.width.toFloat() / bitmap.height.toFloat()
        return if (sourceRatio > targetRatio) {
            val cropWidth = (bitmap.height * targetRatio).toInt().coerceAtLeast(1)
            val left = (bitmap.width - cropWidth) / 2
            Rect(left, 0, left + cropWidth, bitmap.height)
        } else {
            val cropHeight = (bitmap.width / targetRatio).toInt().coerceAtLeast(1)
            val top = (bitmap.height - cropHeight) / 2
            Rect(0, top, bitmap.width, min(bitmap.height, top + cropHeight))
        }
    }

    private fun recycleFrames() {
        frames.filterNotNull().forEach { bitmap ->
            if (!bitmap.isRecycled) runCatching { bitmap.recycle() }
        }
    }

    override fun onDetachedFromWindow() {
        generation.incrementAndGet()
        recycleFrames()
        worker.shutdownNow()
        super.onDetachedFromWindow()
    }
}
