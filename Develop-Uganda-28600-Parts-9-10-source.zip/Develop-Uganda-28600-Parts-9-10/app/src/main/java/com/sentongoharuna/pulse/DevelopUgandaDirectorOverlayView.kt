package com.sentongoharuna.pulse

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.max
import kotlin.math.roundToInt

/** A strictly physical, on-device face observation for Interview Cam. */
data class DevelopUgandaFaceObservation(
    val observedAtMs: Long,
    val subjectId: String,
    val centerX: Float,
    val centerY: Float,
    val areaRatio: Float,
    val yawDegrees: Float,
    val rollDegrees: Float,
    val leftEyeOpen: Float?,
    val rightEyeOpen: Float?,
    val smileProbability: Float?,
    val faceCount: Int
)

/**
 * V227 screen-only Director + Preview Histogram.
 *
 * This view never participates in CameraX OverlayEffect, so its face guides
 * and histogram are operator aids only and are never burned into saved media.
 */
class DevelopUgandaDirectorOverlayView(
    context: Context,
    private val interviewObservationsEnabled: Boolean = false
) : View(context) {

    private val worker =
        Executors.newSingleThreadExecutor()

    private val busy =
        AtomicBoolean(false)

    private val faceDetector: FaceDetector =
        FaceDetection.getClient(
            FaceDetectorOptions.Builder()
                .setPerformanceMode(
                    FaceDetectorOptions.PERFORMANCE_MODE_FAST
                )
                .setMinFaceSize(
                    0.12f
                )
                .apply {
                    // Main and Live retain their original FAST detector.
                    // Interview Cam asks this same overlay layer for the
                    // additional classifier/tracking values it can observe.
                    if (interviewObservationsEnabled) {
                        setClassificationMode(
                            FaceDetectorOptions.CLASSIFICATION_MODE_ALL
                        )
                        enableTracking()
                    }
                }
                .build()
        )

    @Volatile
    private var enabled =
        true

    @Volatile
    private var peopleMode =
        false

    @Volatile
    private var inputWidth =
        1

    @Volatile
    private var inputHeight =
        1

    @Volatile
    private var faces =
        emptyList<Face>()

    private data class DetectionBoxMotion(
        val id: String,
        val from: RectF,
        val to: RectF,
        val startedAtMs: Long,
        val primary: Boolean,
        val measuredAreaRatio: Float,
        val lockState: String,
    )

    private val detectionLock = Any()

    @Volatile
    private var detectionBoxes = emptyList<DetectionBoxMotion>()

    @Volatile
    private var lastDetectionAtMs = 0L

    @Volatile
    private var detectionBoxesEnabled = interviewObservationsEnabled

    @Volatile
    private var detectionLegendEnabled = false

    private val detectionLegendBounds = RectF()

    private val detectionInterpolator =
        DevelopUgandaFivemods8Theme.motionInterpolator(context)

    @Volatile
    private var primaryFaceListener: ((Float, Float, Float) -> Unit)? =
        null

    @Volatile
    private var interviewObservationListener:
        ((DevelopUgandaFaceObservation) -> Unit)? = null


    @Volatile
    private var trackingMode = "OFF"

    @Volatile
    private var trackingAnchorX: Float? = null

    @Volatile
    private var trackingAnchorY: Float? = null

    @Volatile
    private var histogram =
        IntArray(
            32
        )

    @Volatile
    private var histogramMax =
        1

    @Volatile
    private var histogramMessage =
        "PREVIEW HISTOGRAM • ANALYSING"

    @Volatile
    private var compositionMessage =
        "DIRECTOR • COMPOSITION READY"

    private val guidePaint =
        Paint(
            Paint.ANTI_ALIAS_FLAG
        ).apply {
            color =
                DevelopUgandaFivemods8Theme.contentDim

            style =
                Paint.Style.STROKE

            strokeWidth =
                3f
        }

    private val warningPaint =
        Paint(
            Paint.ANTI_ALIAS_FLAG
        ).apply {
            color =
                DevelopUgandaFivemods8Theme.accent

            style =
                Paint.Style.STROKE

            strokeWidth =
                3f
        }

    private val gridPaint =
        Paint(
            Paint.ANTI_ALIAS_FLAG
        ).apply {
            color =
                DevelopUgandaFivemods8Theme.contentScrim(40)

            strokeWidth =
                1f
        }

    private val panelPaint =
        Paint(
            Paint.ANTI_ALIAS_FLAG
        ).apply {
            color =
                DevelopUgandaFivemods8Theme.surfaceScrim(204)

            style =
                Paint.Style.FILL
        }

    private val histogramPaint =
        Paint(
            Paint.ANTI_ALIAS_FLAG
        ).apply {
            color =
                DevelopUgandaFivemods8Theme.accent

            style =
                Paint.Style.FILL
        }

    private val labelPaint =
        Paint(
            Paint.ANTI_ALIAS_FLAG
        ).apply {
            color =
                DevelopUgandaFivemods8Theme.content

            textSize =
                22f

        }

    private val detectionPaint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = resources.displayMetrics.density
        }

    private val detectionTextPaint =
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            textSize = resources.displayMetrics.scaledDensity * 11f
            typeface = android.graphics.Typeface.create(
                android.graphics.Typeface.MONOSPACE,
                android.graphics.Typeface.BOLD,
            )
        }

    fun setPrimaryFaceListener(
        listener: ((Float, Float, Float) -> Unit)?
    ) {
        primaryFaceListener =
            listener
    }

    fun setInterviewObservationListener(
        listener: ((DevelopUgandaFaceObservation) -> Unit)?
    ) {
        interviewObservationListener = listener
    }


    fun setTrackingMode(value: String) {
        trackingMode = value.trim().uppercase()
        if (trackingMode == "OFF") {
            trackingAnchorX = null
            trackingAnchorY = null
        }
        postInvalidateOnAnimation()
    }

    fun setTrackingAnchor(normalizedX: Float, normalizedY: Float) {
        trackingAnchorX = normalizedX.coerceIn(0f, 1f)
        trackingAnchorY = normalizedY.coerceIn(0f, 1f)
        postInvalidateOnAnimation()
    }

    fun setDetectionBoxesEnabled(value: Boolean) {
        detectionBoxesEnabled = value
        if (!value) clearDetectionBoxes()
        postInvalidateOnAnimation()
    }

    fun setDetectionLegendEnabled(value: Boolean) {
        detectionLegendEnabled = value
        postInvalidateOnAnimation()
    }

    /** Called before subject selection so the dismiss target never selects a face. */
    fun dismissDetectionLegendIfHit(x: Float, y: Float): Boolean {
        if (!detectionLegendEnabled || !detectionLegendBounds.contains(x, y)) return false
        detectionLegendEnabled = false
        postInvalidateOnAnimation()
        return true
    }

    fun setDirectorEnabled(
        value: Boolean
    ) {
        enabled =
            value

        if (
            !value
        ) {
            faces =
                emptyList()

            clearDetectionBoxes()

            histogram =
                IntArray(
                    32
                )

            compositionMessage =
                "DIRECTOR • OFF"
        }

        postInvalidateOnAnimation()
    }

    fun submitFrame(
        source: Bitmap,
        enablePeopleGuidance: Boolean
    ) {
        if (
            !enabled ||
            source.width <=
                0 ||
            source.height <=
                0 ||
            !busy.compareAndSet(
                false,
                true
            )
        ) {
            return
        }

        peopleMode =
            enablePeopleGuidance

        worker.execute {
            var scaled: Bitmap? =
                null

            try {
                val targetWidth =
                    minOf(
                        420,
                        source.width
                    )
                        .coerceAtLeast(
                            96
                        )

                val targetHeight =
                    max(
                        96,
                        (
                            source.height.toFloat() *
                                targetWidth.toFloat() /
                                source.width.toFloat()
                            ).roundToInt()
                    )

                scaled =
                    Bitmap.createScaledBitmap(
                        source,
                        targetWidth,
                        targetHeight,
                        false
                    )

                inputWidth =
                    scaled.width

                inputHeight =
                    scaled.height

                calculateHistogram(
                    scaled
                )

                if (
                    !enablePeopleGuidance
                ) {
                    faces =
                        emptyList()

                    clearDetectionBoxes()

                    compositionMessage =
                        "DIRECTOR • GRID / HISTOGRAM"

                    val finished =
                        scaled

                    post {
                        postInvalidateOnAnimation()
                    }

                    try {
                        finished.recycle()
                    } catch (_: Exception) {
                    }

                    busy.set(
                        false
                    )

                    return@execute
                }

                val image =
                    InputImage.fromBitmap(
                        scaled,
                        0
                    )

                val imageForClose =
                    scaled

                faceDetector
                    .process(
                        image
                    )
                    .addOnSuccessListener {
                            detected ->
                        val sorted =
                            detected
                                .sortedByDescending {
                                    it.boundingBox.width() *
                                        it.boundingBox.height()
                                }

                        val selected =
                            when (trackingMode) {
                                "TAP FACE" -> {
                                    val ax = trackingAnchorX
                                    val ay = trackingAnchorY
                                    if (ax != null && ay != null && inputWidth > 0 && inputHeight > 0) {
                                        sorted.minByOrNull { face ->
                                            val box = face.boundingBox
                                            val cx = (box.left + box.right) / 2f / inputWidth.toFloat()
                                            val cy = (box.top + box.bottom) / 2f / inputHeight.toFloat()
                                            val dx = cx - ax
                                            val dy = cy - ay
                                            dx * dx + dy * dy
                                        }
                                    } else {
                                        sorted.firstOrNull()
                                    }
                                }

                                "PRIMARY FACE" ->
                                    sorted.firstOrNull()

                                else ->
                                    sorted.firstOrNull()
                            }

                        faces =
                            if (trackingMode != "OFF" && selected != null) {
                                listOf(selected) + sorted.filterNot { it === selected }
                            } else {
                                sorted
                            }

                        updateDetectionBoxes(faces)

                        val primary = faces.firstOrNull()

                        compositionMessage =
                            if (trackingMode != "OFF") {
                                if (primary != null) {
                                    "TRACK • FACE LOCK • ${trackingMode}"
                                } else {
                                    "TRACK • SEARCHING FOR FACE"
                                }
                            } else {
                                compositionFor(primary)
                            }

                        if (
                            primary != null &&
                            inputWidth > 0 &&
                            inputHeight > 0
                        ) {
                            val box = primary.boundingBox
                            val centerX = (box.left + box.right) / 2f / inputWidth.toFloat()
                            val centerY = (box.top + box.bottom) / 2f / inputHeight.toFloat()
                            val areaRatio =
                                (box.width().toFloat() * box.height().toFloat()) /
                                    (inputWidth.toFloat() * inputHeight.toFloat())

                            if (trackingMode == "TAP FACE") {
                                trackingAnchorX = centerX.coerceIn(0f, 1f)
                                trackingAnchorY = centerY.coerceIn(0f, 1f)
                            }

                            primaryFaceListener?.invoke(
                                centerX.coerceIn(0f, 1f),
                                centerY.coerceIn(0f, 1f),
                                areaRatio.coerceIn(0f, 1f)
                            )

                            if (interviewObservationsEnabled) {
                                interviewObservationListener?.invoke(
                                    DevelopUgandaFaceObservation(
                                        observedAtMs = android.os.SystemClock.elapsedRealtime(),
                                        subjectId = primary.trackingId?.toString() ?: "face-0",
                                        centerX = centerX.coerceIn(0f, 1f),
                                        centerY = centerY.coerceIn(0f, 1f),
                                        areaRatio = areaRatio.coerceIn(0f, 1f),
                                        yawDegrees = primary.headEulerAngleY,
                                        rollDegrees = primary.headEulerAngleZ,
                                        leftEyeOpen = primary.leftEyeOpenProbability,
                                        rightEyeOpen = primary.rightEyeOpenProbability,
                                        smileProbability = primary.smilingProbability,
                                        faceCount = sorted.size
                                    )
                                )
                            }
                        }

                        postInvalidateOnAnimation()
                    }
                    .addOnFailureListener {
                        faces =
                            emptyList()

                        clearDetectionBoxes()

                        compositionMessage =
                            "DIRECTOR • FACE CHECK UNAVAILABLE"

                        postInvalidateOnAnimation()
                    }
                    .addOnCompleteListener {
                        try {
                            imageForClose.recycle()
                        } catch (_: Exception) {
                        }

                        busy.set(
                            false
                        )
                    }
            } catch (_: Exception) {
                try {
                    scaled?.recycle()
                } catch (_: Exception) {
                }

                clearDetectionBoxes()

                busy.set(
                    false
                )
            }
        }
    }

    private fun clearDetectionBoxes() {
        synchronized(detectionLock) {
            detectionBoxes = emptyList()
            lastDetectionAtMs = 0L
        }
    }

    private fun updateDetectionBoxes(orderedFaces: List<Face>) {
        if (!detectionBoxesEnabled || inputWidth <= 0 || inputHeight <= 0 || orderedFaces.isEmpty()) {
            clearDetectionBoxes()
            return
        }
        val now = SystemClock.uptimeMillis()
        synchronized(detectionLock) {
            val old = detectionBoxes.associateBy { it.id }
            detectionBoxes = orderedFaces.take(3).mapIndexed { index, face ->
                val box = face.boundingBox
                val target = RectF(
                    box.left.toFloat() / inputWidth.toFloat(),
                    box.top.toFloat() / inputHeight.toFloat(),
                    box.right.toFloat() / inputWidth.toFloat(),
                    box.bottom.toFloat() / inputHeight.toFloat(),
                )
                val id = face.trackingId?.toString() ?: "face-${orderedFaces.indexOf(face)}"
                val previous = old[id]
                val start = previous?.let { interpolatedRect(it, now) } ?: RectF(target)
                DetectionBoxMotion(
                    id = id,
                    from = start,
                    to = target,
                    startedAtMs = now,
                    primary = trackingMode != "OFF" && index == 0,
                    measuredAreaRatio = (target.width() * target.height()).coerceIn(0f, 1f),
                    lockState = if (trackingMode == "TAP FACE") "TAP LOCK" else "PRIMARY LOCK",
                )
            }
            lastDetectionAtMs = now
        }
        postDelayed(
            {
                if (lastDetectionAtMs == now) {
                    clearDetectionBoxes()
                    postInvalidateOnAnimation()
                }
            },
            DevelopUgandaFivemods8Theme.motionDurationMs * 10L,
        )
    }

    private fun interpolatedRect(box: DetectionBoxMotion, now: Long): RectF {
        val raw = ((now - box.startedAtMs).toFloat() /
            DevelopUgandaFivemods8Theme.motionDurationMs.toFloat()).coerceIn(0f, 1f)
        val amount = detectionInterpolator.getInterpolation(raw)
        return RectF(
            box.from.left + (box.to.left - box.from.left) * amount,
            box.from.top + (box.to.top - box.from.top) * amount,
            box.from.right + (box.to.right - box.from.right) * amount,
            box.from.bottom + (box.to.bottom - box.from.bottom) * amount,
        )
    }

    private fun calculateHistogram(
        bitmap: Bitmap
    ) {
        val bins =
            IntArray(
                32
            )

        var count =
            0

        var sum =
            0L

        var highlights =
            0

        var shadows =
            0

        val step =
            4

        var y =
            0

        while (
            y <
                bitmap.height
        ) {
            var x =
                0

            while (
                x <
                    bitmap.width
            ) {
                val pixel =
                    bitmap.getPixel(
                        x,
                        y
                    )

                val r =
                    Color.red(
                        pixel
                    )

                val g =
                    Color.green(
                        pixel
                    )

                val b =
                    Color.blue(
                        pixel
                    )

                val luma =
                    (
                        r *
                            54 +
                            g *
                                183 +
                            b *
                                19
                        ) /
                        256

                val bin =
                    (
                        luma *
                            bins.size /
                            256
                        )
                        .coerceIn(
                            0,
                            bins.lastIndex
                        )

                bins[
                    bin
                ] +=
                    1

                sum +=
                    luma

                count +=
                    1

                if (
                    luma >=
                        235
                ) {
                    highlights +=
                        1
                }

                if (
                    luma <=
                        25
                ) {
                    shadows +=
                        1
                }

                x +=
                    step
            }

            y +=
                step
        }

        histogram =
            bins

        histogramMax =
            (
                bins.maxOrNull()
                    ?: 1
                )
                .coerceAtLeast(
                    1
                )

        val mean =
            if (
                count >
                    0
            ) {
                sum.toFloat() /
                    count.toFloat()
            } else {
                0f
            }

        val highPct =
            if (
                count >
                    0
            ) {
                highlights.toFloat() /
                    count.toFloat()
            } else {
                0f
            }

        val shadowPct =
            if (
                count >
                    0
            ) {
                shadows.toFloat() /
                    count.toFloat()
            } else {
                0f
            }

        histogramMessage =
            when {
                highPct >
                    0.12f ->
                        "PREVIEW HISTOGRAM • HIGHLIGHTS HIGH"

                shadowPct >
                    0.36f ->
                        "PREVIEW HISTOGRAM • SHADOWS HEAVY"

                mean in
                    85f..180f ->
                        "PREVIEW HISTOGRAM • EXPOSURE BALANCED"

                mean <
                    80f ->
                        "PREVIEW HISTOGRAM • PREVIEW DARK"

                else ->
                    "PREVIEW HISTOGRAM • HIGHLIGHTS SAFE"
            }
    }

    private fun compositionFor(
        face: Face?
    ): String {
        if (
            face ==
                null
        ) {
            return "DIRECTOR • NO FACE CONFIRMED"
        }

        val rect =
            face.boundingBox

        val w =
            inputWidth
                .toFloat()
                .coerceAtLeast(
                    1f
                )

        val h =
            inputHeight
                .toFloat()
                .coerceAtLeast(
                    1f
                )

        val cx =
            rect.centerX() /
                w

        val faceWidth =
            rect.width() /
                w

        val faceHeight =
            rect.height() /
                h

        val estimatedEyeY =
            (
                rect.top +
                    rect.height() *
                        0.33f
                ) /
                h

        return when {
            faceWidth >
                0.62f ||
            faceHeight >
                0.58f ->
                    "DIRECTOR • FACE TOO CLOSE"

            cx <
                0.34f ->
                    "DIRECTOR • MOVE SUBJECT RIGHT"

            cx >
                0.66f ->
                    "DIRECTOR • MOVE SUBJECT LEFT"

            estimatedEyeY <
                0.22f ->
                    "DIRECTOR • EYE LINE HIGH"

            estimatedEyeY >
                0.42f ->
                    "DIRECTOR • EYE LINE LOW"

            else ->
                "DIRECTOR • HEADROOM GOOD • EYE LINE NEAR THIRD"
        }
    }

    override fun onDraw(
        canvas: Canvas
    ) {
        super.onDraw(
            canvas
        )

        if (
            !enabled
        ) {
            return
        }

        val w =
            width.toFloat()

        val h =
            height.toFloat()

        if (
            w <=
                0f ||
            h <=
                0f
        ) {
            return
        }

        canvas.drawLine(
            w /
                3f,
            0f,
            w /
                3f,
            h,
            gridPaint
        )

        canvas.drawLine(
            w *
                2f /
                3f,
            0f,
            w *
                2f /
                3f,
            h,
            gridPaint
        )

        canvas.drawLine(
            0f,
            h /
                3f,
            w,
            h /
                3f,
            gridPaint
        )

        canvas.drawLine(
            0f,
            h *
                2f /
                3f,
            w,
            h *
                2f /
                3f,
            gridPaint
        )

        if (peopleMode && detectionBoxesEnabled) {
            val now = SystemClock.uptimeMillis()
            val safeTop = if (interviewObservationsEnabled) resources.displayMetrics.density * 68f else 0f
            val safeBottom = if (interviewObservationsEnabled) {
                h - max(resources.displayMetrics.density * 204f, h * 0.20f)
            } else {
                h
            }
            val boxes = synchronized(detectionLock) {
                if (lastDetectionAtMs == 0L || now - lastDetectionAtMs >
                    DevelopUgandaFivemods8Theme.motionDurationMs * 10L) {
                    detectionBoxes = emptyList()
                }
                detectionBoxes.toList()
            }
            var easing = false
            canvas.save()
            canvas.clipRect(0f, safeTop, w, safeBottom.coerceAtLeast(safeTop))
            boxes.forEach { box ->
                val normalized = interpolatedRect(box, now)
                val rect = RectF(
                    normalized.left * w,
                    normalized.top * h,
                    normalized.right * w,
                    normalized.bottom * h,
                )
                val band = when {
                    !box.primary -> DevelopUgandaMeasuredBand.UNKNOWN
                    box.measuredAreaRatio < 0.18f -> DevelopUgandaMeasuredBand.NORMAL
                    box.measuredAreaRatio <= 0.30f -> DevelopUgandaMeasuredBand.DEGRADED
                    else -> DevelopUgandaMeasuredBand.CRITICAL
                }
                val color = if (box.primary) band.color() else DevelopUgandaFivemods8Theme.contentDim
                detectionPaint.color = color
                detectionTextPaint.color = color
                canvas.drawRect(rect, detectionPaint)
                if (box.primary) {
                    val measured = String.format(
                        java.util.Locale.US,
                        "ID %s • %s • CROP %.1f%%",
                        box.id,
                        box.lockState,
                        box.measuredAreaRatio * 100f,
                    )
                    val baseline = (rect.top - resources.displayMetrics.density * 4f)
                        .coerceAtLeast(detectionTextPaint.textSize)
                    canvas.drawText(measured, rect.left, baseline, detectionTextPaint)
                }
                if (now - box.startedAtMs < DevelopUgandaFivemods8Theme.motionDurationMs) easing = true
            }
            if (easing) postInvalidateOnAnimation()
            if (detectionLegendEnabled) drawDetectionLegend(canvas, w, safeTop)
            canvas.restore()
        } else {
            detectionLegendBounds.setEmpty()
        }

        val panelLeft =
            18f

        val panelTop =
            (
                h *
                    0.56f
                )
                .coerceIn(
                    190f,
                    h -
                        300f
                )

        val panelBottom =
            panelTop +
                92f

        val panelRight =
            minOf(
                w -
                    18f,
                365f
            )

        canvas.drawRoundRect(
            panelLeft,
            panelTop,
            panelRight,
            panelBottom,
            16f,
            16f,
            panelPaint
        )

        val bins =
            histogram

        val usableW =
            panelRight -
                panelLeft -
                18f

        val usableH =
            48f

        val barW =
            usableW /
                bins.size
                    .toFloat()

        bins.forEachIndexed {
                index,
                value ->
            val fraction =
                value.toFloat() /
                    histogramMax
                        .toFloat()

            val left =
                panelLeft +
                    9f +
                    index *
                        barW

            val bottom =
                panelBottom -
                    13f

            val top =
                bottom -
                    usableH *
                        fraction

            canvas.drawRect(
                left,
                top,
                left +
                    max(
                        1f,
                        barW -
                            1.2f
                    ),
                bottom,
                histogramPaint
            )
        }

        labelPaint.textSize =
            18f

        canvas.drawText(
            histogramMessage,
            panelLeft +
                10f,
            panelTop +
                24f,
            labelPaint
        )

        if (
            peopleMode
        ) {
            val textY =
                (
                    panelTop -
                        18f
                    )
                    .coerceAtLeast(
                        80f
                    )

            canvas.drawRoundRect(
                18f,
                textY -
                    30f,
                w -
                    18f,
                textY +
                    12f,
                13f,
                13f,
                panelPaint
            )

            labelPaint.textSize =
                19f

            canvas.drawText(
                compositionMessage,
                30f,
                textY,
                labelPaint
            )
        }
    }

    private fun drawDetectionLegend(canvas: Canvas, width: Float, safeTop: Float) {
        val margin = resources.displayMetrics.density * 8f
        val lineHeight = detectionTextPaint.textSize * 1.35f
        val values = listOf(
            "BOX BANDS ×" to DevelopUgandaFivemods8Theme.contentDim,
            "CONTENT  <18% CROP" to DevelopUgandaFivemods8Theme.content,
            "WARNING  18–30%" to DevelopUgandaFivemods8Theme.warning,
            "RECORD   >30%" to DevelopUgandaFivemods8Theme.record,
        )
        val widest = values.maxOf { detectionTextPaint.measureText(it.first) }
        val left = (width - widest - margin).coerceAtLeast(margin)
        val top = safeTop + margin + detectionTextPaint.textSize
        values.forEachIndexed { index, (value, color) ->
            detectionTextPaint.color = color
            canvas.drawText(value, left, top + lineHeight * index, detectionTextPaint)
        }
        detectionLegendBounds.set(
            left - margin,
            safeTop,
            width,
            top + lineHeight * values.size,
        )
    }

    override fun onDetachedFromWindow() {
        try {
            faceDetector.close()
        } catch (_: Exception) {
        }

        try {
            worker.shutdownNow()
        } catch (_: Exception) {
        }

        super.onDetachedFromWindow()
    }
}
