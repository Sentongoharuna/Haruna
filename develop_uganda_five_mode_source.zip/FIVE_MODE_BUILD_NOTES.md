# develop.uganda — five-mode camera build

## Mode order

1. **MAIN** — the existing All Pro camera.
2. **LIVE** — the existing live/telemetry camera.
3. **TIKTOK** — 9:16 FHD, 60 fps request, 18 Mbps upload-ready copy.
4. **STATUS** — 9:16 FHD, 30 fps request, 7 Mbps status-ready copy.
5. **INTERVIEW** — single-subject operator observation read-out.

Tap a label in the thin bottom mode strip to change mode. A horizontal swipe
on that strip changes to the adjacent page. The preview itself keeps its
existing gestures so Main and Live behaviour is not changed.

## Preserved code

- `DevelopUgandaLiveActivity.kt` has only the 11-line mode-strip insertion.
  Its recorder, telemetry, UI controls, settings and theme are untouched.
- The established Main Camera remains `DevelopUgandaAllProCameraActivity` and
  retains its existing code path, defaults, controls and settings. It has only
  the additive bottom strip.
- No existing preference key is renamed or repurposed. New-mode values use
  the shared engine's normal per-experience stores:
  `develop_uganda_report_camera_v281_status` and
  `develop_uganda_report_camera_v281_interview`.

The existing app home remains the launcher because replacing it would alter a
built screen outside the requested camera-mode change. It already routes to
the Main Camera; within the five-mode strip, Main is page 1 and the default.

## Delivery behaviour

Every mode first saves its normal CameraX recording as the clean gallery
master. Delivery processing always creates an additional file and never edits,
replaces or deletes that master.

### TikTok Cam

- Portrait 1080 x 1920 target, 60 fps request, H.264/AAC upload copy.
- 18 Mbps encoder target with CBR requested.
- Mild brightness, contrast and saturation lift only on the upload copy.
- No synthetic grain or aggressive sharpening is added.
- Outputs: `Movies/develop.uganda/TikTok Ready` plus the clean master.

### Status Cam

- Portrait 1080 x 1920 target, 30 fps request, H.264/AAC 128 kbps copy.
- 7 Mbps encoder target with CBR requested.
- On the first recording, enter the current video limit shown by WhatsApp on
  this phone. The app stores that Status-only value and safely segments
  continuing recordings at it; no stale hard-coded limit is used.
- Outputs: `Movies/develop.uganda/Status Ready` plus the clean master.
- The resulting file is offered to WhatsApp through Android's public share
  interface. Android does not expose a stable public API that forces a
  specific WhatsApp Status composer, so the user still confirms the Status
  destination in WhatsApp.

Hardware codecs may decline a CBR request. If a delivery encode fails, the
app reports the copy failure while retaining the clean master. The public
Media3 encoder path also does not reliably force H.264 High profile or MP4
fast-start atom placement across all Android devices, so those are not
misrepresented as guarantees.

## Interview Cam

- First use shows an on-device consent notice.
- Tap a face to select the primary subject. The operator can turn on Two Shot
  for framing; in that mode the read-out waits for a deliberate tap and then
  reads only the selected primary subject.
- The preview HUD is operator-only. Burn Strip is off by default. When turned
  on deliberately, it produces a **separate annotated review copy** after the
  clean master is safe.
- The persistent annotated footer is: `Observed physical signals only. Not an
  indicator of truthfulness.`
- A JSON sidecar is written to `Downloads/develop.uganda/Interview`, including
  timestamps, labels, available channels, question markers and composure
  shifts over 25 points.
- All measurement happens on-device. No biometric data is sent by this mode.

This build reuses the existing Director Overlay / ML Kit face layer. It
records only channels it can physically observe today: movement energy,
postural shift, head-pose gaze proxy, blink rate, expression mix and a
composure index. The unavailable hand-contact, facial-tension and live
transcription channels are written as `null` rather than guessed. The labels
are limited to observed-state labels: `SETTLED`, `ACTIVATED`, `AGITATED`,
`PAUSE` and `BASELINE DRIFT`.

## GitHub Actions build

Upload the supplied `develop_uganda_five_mode_source.zip` to the **root** of
the GitHub repository. Upload the supplied
`build-develop-uganda-five-mode.yml` to `.github/workflows/` exactly with that
extension. Commit both, then open **Actions → Build develop.uganda five-mode
APK → Run workflow**. Download the `develop-uganda-five-mode-apk` artifact
from the completed run.

The workflow is intentionally tiny and contains no embedded source data, so
it stays well below GitHub's 500 KB workflow-file limit.
