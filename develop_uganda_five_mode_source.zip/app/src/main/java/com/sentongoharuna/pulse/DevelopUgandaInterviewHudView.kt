package com.sentongoharuna.pulse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import kotlin.math.max

/** Preview-only operator display for Interview Cam. */
class DevelopUgandaInterviewHudView(
    context: Context
) : View(context) {

    private var snapshot: DevelopUgandaInterviewObservationEngine.InterviewObservationSnapshot? = null
    private var analysisEnabled = true
    private var burnInEnabled = false
    private var twoShotEnabled = false

    private val background = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xD9031829.toInt()
    }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF73B7D9.toInt()
    }
    private val marker = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF83B995.toInt()
        strokeWidth = 2f
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 17f
    }
    private val small = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFAEB7C7.toInt()
        textSize = 12f
    }

    fun setSnapshot(value: DevelopUgandaInterviewObservationEngine.InterviewObservationSnapshot) {
        snapshot = value
        postInvalidateOnAnimation()
    }

    fun setAnalysisEnabled(value: Boolean) {
        analysisEnabled = value
        postInvalidateOnAnimation()
    }

    fun setBurnInEnabled(value: Boolean) {
        burnInEnabled = value
        postInvalidateOnAnimation()
    }

    fun setTwoShotEnabled(value: Boolean) {
        twoShotEnabled = value
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val panelWidth = max(190f, width * 0.34f)
        val left = width - panelWidth - 12f
        val top = 86f
        val rowHeight = 34f
        val visibleChannels =
            listOf(
                "MOVEMENT ENERGY",
                "POSTURAL SHIFT",
                "GAZE",
                "BLINK RATE",
                "EXPRESSION MIX",
                "COMPOSURE INDEX"
            )
        val panelHeight = 85f + rowHeight * visibleChannels.size + 72f

        background.color = 0xD9031829.toInt()
        canvas.drawRoundRect(
            RectF(left, top, left + panelWidth, top + panelHeight),
            14f,
            14f,
            background
        )

        if (!analysisEnabled) {
            text.color = 0xFFD0B06F.toInt()
            canvas.drawText("ANALYSIS OFF", left + 12f, top + 27f, text)
            small.color = 0xFFAEB7C7.toInt()
            canvas.drawText("FRAMING REMAINS ACTIVE", left + 12f, top + 49f, small)
        } else {
            val value = snapshot
            text.color = 0xFFAEBDEB.toInt()
            canvas.drawText(
                value?.let { "${it.label} ${it.degree}" } ?: "BASELINE DRIFT",
                left + 12f,
                top + 26f,
                text
            )
            small.color = 0xFFAEB7C7.toInt()
            canvas.drawText(
                value?.drivingChannels?.joinToString(", ")?.take(32) ?: "waiting for face",
                left + 12f,
                top + 48f,
                small
            )

            var y = top + 70f
            visibleChannels.forEach { channel ->
                val score = value?.channels?.get(channel)
                small.color = 0xFFE8F1F2.toInt()
                canvas.drawText(channel.take(11), left + 12f, y + 12f, small)
                val barLeft = left + 98f
                val barWidth = panelWidth - 112f
                background.color = 0x30FFFFFF
                canvas.drawRoundRect(
                    RectF(barLeft, y, barLeft + barWidth, y + 12f),
                    6f,
                    6f,
                    background
                )
                if (score != null) {
                    bar.color =
                        if (channel == "COMPOSURE INDEX") 0xFF83B995.toInt() else 0xFF73B7D9.toInt()
                    canvas.drawRoundRect(
                        RectF(barLeft, y, barLeft + barWidth * (score / 100f), y + 12f),
                        6f,
                        6f,
                        bar
                    )
                    canvas.drawLine(
                        barLeft + barWidth * 0.25f,
                        y - 2f,
                        barLeft + barWidth * 0.25f,
                        y + 14f,
                        marker
                    )
                } else {
                    small.color = 0xFFAEB7C7.toInt()
                    canvas.drawText("--", barLeft + 4f, y + 11f, small)
                }
                y += rowHeight
            }
        }

        small.color = 0xFFAEB7C7.toInt()
        canvas.drawText(
            "BURN ${if (burnInEnabled) "REQUESTED" else "OFF"} • ${if (twoShotEnabled) "TWO-SHOT" else "SINGLE"}",
            left + 12f,
            top + panelHeight - 47f,
            small
        )
        small.color = 0xFFE8F1F2.toInt()
        canvas.drawText(
            "Observed physical signals only.",
            left + 12f,
            top + panelHeight - 28f,
            small
        )
        canvas.drawText(
            "Not an indicator of truthfulness.",
            left + 12f,
            top + panelHeight - 12f,
            small
        )
    }
}
