package com.sentongoharuna.pulse

import android.content.Context
import java.util.Locale

/**
 * V278 • LIVE WORKFLOW HOME.
 *
 * Screen-only orchestration for the first page. It reads the already-working V271–V277
 * modules and turns them into a chronological operator path. It does not fake sensor state,
 * does not overwrite masters and does not force camera settings the device has not exposed.
 * Shot Memory is a reference/match tool: it remembers a working setup and scores the current
 * setup against it so repeat shoots can be made more consistent.
 */
object DevelopUgandaV278LiveWorkflow {
    private const val PREFS = "develop_uganda_v278_live_workflow_home"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    val stages = listOf("READY", "LIGHT", "SOUND", "FRAME", "MOTION", "RECORD", "SAFETY", "REVIEW")

    fun simpleStage(detailedStage: String): String = when (detailedStage.uppercase(Locale.US)) {
        "PREPARE" -> "READY"
        "LIGHT" -> "LIGHT"
        "SOUND" -> "SOUND"
        "CONTINUITY", "FRAME", "FOCUS" -> "FRAME"
        "REHEARSE" -> "MOTION"
        "RECORD" -> "RECORD"
        "VERIFY" -> "SAFETY"
        "REVIEW", "ORGANIZE", "DELIVER" -> "REVIEW"
        else -> "READY"
    }

    private fun audioToken(context: Context): String {
        val raw = try { DevelopUgandaV272FieldSoundContinuity.audioInputSummary(context) } catch (_: Exception) { "AUDIO UNKNOWN" }
        return when {
            raw.contains("PERMISSION", true) -> "MIC PERMISSION"
            raw.contains("NONE", true) -> "MIC CHECK"
            else -> "AUDIO GOOD"
        }
    }

    private fun lightToken(context: Context): String = when {
        !DevelopUgandaV277LightingExposure.hasFreshReading(context) -> "LIGHT CHECK"
        DevelopUgandaV277LightingExposure.needsAttention(context) -> "LIGHT ATTENTION"
        else -> "LIGHT GOOD"
    }

    private fun safetyToken(context: Context): String =
        if (DevelopUgandaV276RecordingSafety.needsRecoveryReview(context)) "SAFETY CHECK" else "REC SAFE"

    fun liveStatus(context: Context, detailedStage: String, readinessScore: Int): String {
        val stage = simpleStage(detailedStage)
        val motion = try { DevelopUgandaV273MotionShotControl.shotMode(context) } catch (_: Exception) { "SHOT" }
        val clips = try { DevelopUgandaV274MediaVaultStore.clips(context).size } catch (_: Exception) { 0 }
        return "● LIVE $stage • READY ${readinessScore.coerceIn(0, 100)} • ${lightToken(context)} • ${audioToken(context)} • $motion • ${safetyToken(context)} • CLIPS $clips"
    }

    fun nextBestAction(context: Context, detailedStage: String): String = when (detailedStage.uppercase(Locale.US)) {
        "PREPARE" -> "NEXT BEST ACTION • Run the ready check: battery, storage, thermal state and project identity."
        "LIGHT" -> "NEXT BEST ACTION • Fix exposure first. Check face/spot meter, highlights, shadows and flicker guidance."
        "SOUND" -> "NEXT BEST ACTION • Confirm microphone route and run Audio Check before framing the take."
        "CONTINUITY" -> "NEXT BEST ACTION • Save or match continuity before changing composition."
        "FRAME" -> "NEXT BEST ACTION • Lock aspect/LUT preview, horizon and composition before movement."
        "REHEARSE" -> "NEXT BEST ACTION • Rehearse motion; save START/END movement, focus and zoom intent."
        "FOCUS" -> "NEXT BEST ACTION • Confirm tracking / focus A-B / metering, then record."
        "RECORD" -> "NEXT BEST ACTION • Ready to record. REC stays available even if guidance is unfinished."
        "VERIFY" -> "NEXT BEST ACTION • Verify the finalized recording or review the interrupted session before another critical take."
        "REVIEW" -> "NEXT BEST ACTION • Rate the newest take BEST / KEEP / RETAKE while the shot is fresh."
        "ORGANIZE" -> "NEXT BEST ACTION • Name, protect and organize the selected masters in Media Vault."
        "DELIVER" -> "NEXT BEST ACTION • Check the delivery queue; render-required formats stay clearly marked."
        else -> "NEXT BEST ACTION • Open Camera and follow the highlighted workflow stage."
    }

    private fun currentProject(context: Context): String {
        val p = context.getSharedPreferences("develop_uganda_v260_project_control_failsafe", Context.MODE_PRIVATE)
        return (p.getString("project_name", "FIELD PROJECT") ?: "FIELD PROJECT").trim().ifBlank { "FIELD PROJECT" }
    }

    private fun currentProfile(context: Context): String = try {
        DevelopUgandaV275ControlSurface.selectedProfile(context)
    } catch (_: Exception) { "DEFAULT" }

    private fun currentOutput(context: Context): String = try {
        DevelopUgandaV271LiveCoach.outputMode(context)
    } catch (_: Exception) { "MASTER" }

    private fun currentShot(context: Context): String = try {
        DevelopUgandaV273MotionShotControl.shotMode(context)
    } catch (_: Exception) { "STATIC" }

    private fun currentLight(context: Context): String {
        val s = DevelopUgandaV277LightingExposure.lastSnapshot(context)
        return if (s.isFresh()) s.warmCool else "LIGHT UNKNOWN"
    }

    fun saveShotMemory(context: Context): String {
        val p = prefs(context)
        val count = p.getInt("memory_count", 0) + 1
        p.edit()
            .putBoolean("has_memory", true)
            .putInt("memory_count", count)
            .putLong("saved_at", System.currentTimeMillis())
            .putString("project", currentProject(context))
            .putString("profile", currentProfile(context))
            .putString("output", currentOutput(context))
            .putString("shot", currentShot(context))
            .putString("light", currentLight(context))
            .putString("audio", audioToken(context))
            .apply()
        return "SHOT MEMORY %02d SAVED".format(Locale.US, count.coerceAtMost(99))
    }

    fun clearShotMemory(context: Context) {
        prefs(context).edit().clear().apply()
    }

    fun hasShotMemory(context: Context): Boolean = prefs(context).getBoolean("has_memory", false)

    fun matchScore(context: Context): Int {
        val p = prefs(context)
        if (!p.getBoolean("has_memory", false)) return 0
        var score = 0
        if (p.getString("project", "") == currentProject(context)) score += 10
        if (p.getString("profile", "") == currentProfile(context)) score += 20
        if (p.getString("output", "") == currentOutput(context)) score += 20
        if (p.getString("shot", "") == currentShot(context)) score += 20
        if (p.getString("light", "") == currentLight(context)) score += 15
        if (p.getString("audio", "") == audioToken(context)) score += 15
        return score.coerceIn(0, 100)
    }

    fun memoryStatus(context: Context): String {
        val p = prefs(context)
        if (!p.getBoolean("has_memory", false)) return "SHOT MEMORY • no reference saved • tap MEM SAVE when a setup is right"
        val count = p.getInt("memory_count", 1)
        val profile = p.getString("profile", "DEFAULT") ?: "DEFAULT"
        val shot = p.getString("shot", "STATIC") ?: "STATIC"
        val output = p.getString("output", "MASTER") ?: "MASTER"
        val memoryCode = count.coerceIn(0, 99).toString().padStart(2, '0')
return "SHOT MEMORY $memoryCode • MATCH ${matchScore(context)}% • $profile • $shot • $output"
    }
}
