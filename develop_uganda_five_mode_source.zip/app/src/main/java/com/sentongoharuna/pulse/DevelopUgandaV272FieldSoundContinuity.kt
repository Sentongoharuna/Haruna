package com.sentongoharuna.pulse

import android.Manifest
import android.app.AlertDialog
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.Locale
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * V272 FIELD SOUND + CONTINUITY ENGINE.
 *
 * Real functions in this layer:
 * - Enumerates currently detected Android audio-input devices.
 * - Performs an actual short AudioRecord microphone test when permission allows.
 * - Stores/restores extended camera-continuity metadata.
 * - Captures a real preview reference frame and can display it as a screen-only ghost overlay.
 *
 * Deliberately NOT faked:
 * - CameraX does not expose a universal second safety-track recorder here.
 * - True encoded pre-roll is not claimed until the recording pipeline owns a verified buffer.
 */
object DevelopUgandaV272FieldSoundContinuity {
    const val PREFS = "develop_uganda_v272_field_sound_continuity"
    private const val REF_FILE = "v272_continuity_reference.jpg"
    private const val GHOST_TAG = "v272_ghost_overlay"

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun bool(context: Context, key: String, defaultValue: Boolean): Boolean =
        prefs(context).getBoolean(key, defaultValue)

    fun toggle(context: Context, key: String, defaultValue: Boolean, label: String): String {
        val next = !bool(context, key, defaultValue)
        prefs(context).edit().putBoolean(key, next).apply()
        return "$label ${if (next) "ON" else "OFF"}"
    }

    fun preRollSeconds(context: Context): Int =
        prefs(context).getInt("pre_roll_seconds", 0).let { if (it in listOf(0,3,5,10)) it else 0 }

    fun setPreRollSeconds(context: Context, seconds: Int): String {
        val value = if (seconds in listOf(0,3,5,10)) seconds else 0
        prefs(context).edit().putInt("pre_roll_seconds", value).apply()
        return if (value == 0) "PRE-ROLL REQUEST • OFF" else "PRE-ROLL REQUEST • ${value}s • NOT YET VERIFIED"
    }

    fun saveState(context: Context, json: JSONObject) {
        prefs(context).edit()
            .putString("reference_state", json.toString())
            .putLong("reference_saved_ms", System.currentTimeMillis())
            .apply()
    }

    fun loadState(context: Context): JSONObject? = try {
        prefs(context).getString("reference_state", null)?.let(::JSONObject)
    } catch (_: Exception) { null }

    fun hasReference(context: Context): Boolean =
        referenceFile(context).exists() && loadState(context) != null

    fun referenceFile(context: Context): File = File(context.filesDir, REF_FILE)

    fun saveReferenceBitmap(context: Context, bitmap: Bitmap?): Boolean {
        if (bitmap == null || bitmap.width < 8 || bitmap.height < 8) return false
        return try {
            FileOutputStream(referenceFile(context)).use { out ->
                bitmap.compress(Bitmap.CompressFormat.JPEG, 84, out)
            }
            true
        } catch (_: Exception) { false }
    }

    fun attach(activity: DevelopUgandaCameraActivity, root: FrameLayout) {
        if (root.findViewWithTag<View>(GHOST_TAG) != null) return
        val ghost = ImageView(activity).apply {
            tag = GHOST_TAG
            scaleType = ImageView.ScaleType.CENTER_CROP
            alpha = 0.18f
            visibility = View.GONE
            isClickable = false
            isFocusable = false
            contentDescription = "V272 continuity reference overlay"
        }
        val params = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
        // Preview is child 0 and preview-tone is child 1 in the camera deck.
        // Insert above those but below HUD/controls so this remains a true camera-image aid.
        root.addView(ghost, minOf(2, root.childCount), params)
        refreshGhost(activity, root)
    }

    fun refreshGhost(activity: DevelopUgandaCameraActivity, root: FrameLayout? = null) {
        val host = root ?: activity.findViewById<FrameLayout>(android.R.id.content)?.getChildAt(0) as? FrameLayout
        val ghost = host?.findViewWithTag<ImageView>(GHOST_TAG) ?: return
        val enabled = bool(activity, "ghost_overlay", false)
        val file = referenceFile(activity)
        if (!enabled || !file.exists()) {
            ghost.setImageDrawable(null)
            ghost.visibility = View.GONE
            return
        }
        try {
            val bitmap = BitmapFactory.decodeFile(file.absolutePath)
            if (bitmap != null) {
                ghost.setImageBitmap(bitmap)
                ghost.alpha = prefs(activity).getInt("ghost_alpha", 18).coerceIn(8, 45) / 100f
                ghost.visibility = View.VISIBLE
            } else {
                ghost.visibility = View.GONE
            }
        } catch (_: Exception) {
            ghost.visibility = View.GONE
        }
    }

    fun setGhostAlpha(context: Context, percent: Int): String {
        val value = percent.coerceIn(8,45)
        prefs(context).edit().putInt("ghost_alpha", value).apply()
        return "GHOST STRENGTH • $value%"
    }

    fun ghostAlpha(context: Context): Int = prefs(context).getInt("ghost_alpha",18).coerceIn(8,45)

    fun audioInputSummary(context: Context): String {
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            return "MIC PERMISSION • REQUIRED"
        }
        return try {
            val manager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val inputs = manager.getDevices(AudioManager.GET_DEVICES_INPUTS)
            if (inputs.isEmpty()) return "INPUT • NONE DETECTED"
            val labels = inputs.map { deviceLabel(it) }.distinct().take(3)
            "INPUT • ${labels.joinToString(" + ")}"
        } catch (_: Exception) {
            "INPUT • DEVICE MANAGED"
        }
    }

    private fun deviceLabel(info: AudioDeviceInfo): String = when (info.type) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "PHONE MIC"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "WIRED MIC"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET -> "USB MIC"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "BLUETOOTH MIC"
        else -> "MIC ${info.type}"
    }

    fun runAudioTest(activity: DevelopUgandaCameraActivity, callback: (String) -> Unit) {
        if (ContextCompat.checkSelfPermission(activity, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            callback("MIC TEST • PERMISSION REQUIRED")
            return
        }
        Thread {
            val sampleRate = 16000
            val min = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            )
            if (min <= 0) {
                activity.runOnUiThread { callback("MIC TEST • DEVICE UNAVAILABLE") }
                return@Thread
            }
            var record: AudioRecord? = null
            var result = "MIC TEST • FAILED"
            try {
                val bufferSize = maxOf(min * 2, 4096)
                record = AudioRecord.Builder()
                    .setAudioSource(MediaRecorder.AudioSource.VOICE_RECOGNITION)
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                            .setSampleRate(sampleRate)
                            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(bufferSize)
                    .build()
                if (record.state != AudioRecord.STATE_INITIALIZED) throw IllegalStateException("AudioRecord not initialized")
                val data = ShortArray(bufferSize / 2)
                record.startRecording()
                val deadline = System.currentTimeMillis() + 1400L
                var peak = 0
                var sumSq = 0.0
                var samples = 0L
                while (System.currentTimeMillis() < deadline) {
                    val read = record.read(data, 0, data.size)
                    if (read <= 0) continue
                    for (i in 0 until read) {
                        val a = kotlin.math.abs(data[i].toInt())
                        if (a > peak) peak = a
                        val n = data[i] / 32768.0
                        sumSq += n * n
                    }
                    samples += read
                }
                val rms = if (samples > 0) sqrt(sumSq / samples) else 0.0
                val peakNorm = (peak / 32768.0).coerceAtLeast(0.000001)
                val peakDb = 20.0 * log10(peakNorm)
                val rmsDb = 20.0 * log10(rms.coerceAtLeast(0.000001))
                val state = when {
                    peakDb > -1.5 -> "CLIP RISK"
                    rmsDb < -48.0 -> "VERY LOW"
                    rmsDb < -34.0 -> "LOW"
                    else -> "VOICE OK"
                }
                result = String.format(Locale.US, "MIC TEST • %s • RMS %.1fdBFS • PEAK %.1fdBFS", state, rmsDb, peakDb)
            } catch (e: Exception) {
                result = "MIC TEST • ${e.javaClass.simpleName.uppercase(Locale.US)}"
            } finally {
                try { record?.stop() } catch (_: Exception) {}
                try { record?.release() } catch (_: Exception) {}
            }
            prefs(activity).edit().putString("last_audio_test", result).apply()
            activity.runOnUiThread { callback(result) }
        }.start()
    }

    fun lastAudioTest(context: Context): String = prefs(context).getString("last_audio_test", "MIC TEST • NOT RUN") ?: "MIC TEST • NOT RUN"

    fun armAudioLock(context: Context) {
        if (!bool(context, "audio_lock", true)) return
        prefs(context).edit().putString("locked_input", audioInputSummary(context)).apply()
    }

    fun audioRouteChanged(context: Context): Boolean {
        if (!bool(context, "audio_lock", true)) return false
        val locked = prefs(context).getString("locked_input", "").orEmpty()
        if (locked.isBlank()) return false
        return locked != audioInputSummary(context)
    }

    fun lockedAudioInput(context: Context): String = prefs(context).getString("locked_input", "NOT ARMED") ?: "NOT ARMED"

    fun verificationSummary(context: Context): String = buildString {
        append("LIVE AUDIO METER • WORKING DURING CameraX RECORD\n")
        append("INPUT DETECTION • WORKING • ").append(audioInputSummary(context)).append('\n')
        append("REAL MIC TEST • WORKING WITH PERMISSION\n")
        append("REFERENCE FRAME • ").append(if (hasReference(context)) "WORKING" else "READY / NO REFERENCE").append('\n')
        append("GHOST OVERLAY • ").append(if (bool(context,"ghost_overlay",false)) "ON • SCREEN ONLY" else "OFF").append('\n')
        append("CONTINUITY RESTORE • WORKING FOR APP-CONTROLLABLE SETTINGS\n")
        append("SECOND SAFETY AUDIO TRACK • DEVICE / PIPELINE LIMITED\n")
        val pre = preRollSeconds(context)
        append("ENCODED PRE-ROLL • ").append(if (pre == 0) "OFF / NOT CLAIMED" else "${pre}s REQUESTED • NOT YET VERIFIED")
    }

    fun hubSummary(context: Context): String {
        val input = audioInputSummary(context).removePrefix("INPUT • ")
        val ref = if (hasReference(context)) "REF READY" else "NO REF"
        val pre = preRollSeconds(context)
        return "SOUND $input • CONTINUITY $ref • PRE-ROLL ${if (pre == 0) "OFF" else "${pre}s REQUEST"}"
    }

    fun showVerification(activity: DevelopUgandaCameraActivity) {
        AlertDialog.Builder(activity)
            .setTitle("V272 • VERIFICATION CENTER")
            .setMessage(verificationSummary(activity))
            .setPositiveButton("DONE", null)
            .show()
    }
}
