package com.sentongoharuna.pulse

import android.app.Activity
import android.content.Context
import java.util.Locale

/**
 * V280/12 FIX1 runtime guard.
 *
 * Records the exact route that was opened and the last uncaught runtime fault so
 * the next launch can identify which destination failed. The guard never changes
 * camera media, recording settings or master files.
 */
object DevelopUgandaV28012RuntimeGuard {
    private const val PREFS = "develop_uganda_v28012_runtime_guard"
    private const val MAX_STACK = 7000
    @Volatile private var installed = false

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun install(context: Context) {
        if (installed) return
        synchronized(this) {
            if (installed) return
            val app = context.applicationContext
            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { thread, error ->
                runCatching { recordCrash(app, thread, error) }
                previous?.uncaughtException(thread, error)
            }
            installed = true
        }
    }

    fun markRoute(activity: Activity, destination: Class<out Activity>) {
        prefs(activity).edit()
            .putString("pending_route", destination.name)
            .putString("pending_label", destination.simpleName)
            .putLong("pending_ms", System.currentTimeMillis())
            .apply()
    }

    fun clearPendingRoute(context: Context) {
        prefs(context).edit()
            .remove("pending_route")
            .remove("pending_label")
            .remove("pending_ms")
            .apply()
    }

    fun markReturnedToHub(context: Context) {
        val p = prefs(context)
        val route = safeString(p.all["pending_label"], "")
        if (route.isNotBlank()) {
            p.edit()
                .putString("last_returned_route", route)
                .putLong("last_returned_ms", System.currentTimeMillis())
                .remove("pending_route")
                .remove("pending_label")
                .remove("pending_ms")
                .apply()
        }
    }

    fun recordUiFault(context: Context, area: String, error: Throwable) {
        prefs(context).edit()
            .putString("last_ui_area", area.take(80))
            .putString("last_ui_error", error.javaClass.simpleName)
            .putString("last_ui_message", (error.message ?: "no message").take(500))
            .putLong("last_ui_ms", System.currentTimeMillis())
            .apply()
    }

    private fun recordCrash(context: Context, thread: Thread, error: Throwable) {
        val p = prefs(context)
        val route = safeString(p.all["pending_label"], "HOME / UNKNOWN")
        val stack = error.stackTraceToString().take(MAX_STACK)
        p.edit()
            .putString("last_crash_route", route)
            .putString("last_crash_exception", error.javaClass.name)
            .putString("last_crash_message", (error.message ?: "no message").take(700))
            .putString("last_crash_thread", thread.name.take(80))
            .putString("last_crash_stack", stack)
            .putLong("last_crash_ms", System.currentTimeMillis())
            .apply()
    }

    fun lastCrashSummary(context: Context): String? {
        val p = prefs(context)
        val whenMs = safeLong(p.all["last_crash_ms"], 0L)
        if (whenMs <= 0L) return null
        val age = System.currentTimeMillis() - whenMs
        if (age > 7L * 24L * 60L * 60L * 1000L) return null
        val route = safeString(p.all["last_crash_route"], "UNKNOWN")
        val ex = safeString(p.all["last_crash_exception"], "RuntimeError").substringAfterLast('.')
        val msg = safeString(p.all["last_crash_message"], "no message").replace('\n', ' ').take(180)
        return "LAST RUNTIME FAULT • $route • $ex • $msg"
    }

    fun fullCrashReport(context: Context): String {
        val p = prefs(context)
        return buildString {
            append("V280/12 RUNTIME REPORT\n")
            append("ROUTE: ").append(safeString(p.all["last_crash_route"], "UNKNOWN")).append('\n')
            append("EXCEPTION: ").append(safeString(p.all["last_crash_exception"], "UNKNOWN")).append('\n')
            append("MESSAGE: ").append(safeString(p.all["last_crash_message"], "no message")).append('\n')
            append("THREAD: ").append(safeString(p.all["last_crash_thread"], "unknown")).append('\n')
            append("STACK:\n").append(safeString(p.all["last_crash_stack"], "not recorded"))
        }
    }

    fun safeString(value: Any?, fallback: String): String = when (value) {
        is String -> value
        null -> fallback
        else -> value.toString()
    }

    fun safeInt(value: Any?, fallback: Int): Int = when (value) {
        is Int -> value
        is Long -> value.toInt()
        is Float -> value.toInt()
        is Double -> value.toInt()
        is String -> value.trim().toIntOrNull() ?: fallback
        else -> fallback
    }

    fun safeLong(value: Any?, fallback: Long): Long = when (value) {
        is Long -> value
        is Int -> value.toLong()
        is Float -> value.toLong()
        is Double -> value.toLong()
        is String -> value.trim().toLongOrNull() ?: fallback
        else -> fallback
    }

    fun safeBoolean(value: Any?, fallback: Boolean): Boolean = when (value) {
        is Boolean -> value
        is String -> when (value.trim().uppercase(Locale.US)) {
            "TRUE", "ON", "YES", "1" -> true
            "FALSE", "OFF", "NO", "0" -> false
            else -> fallback
        }
        is Number -> value.toInt() != 0
        else -> fallback
    }
}
