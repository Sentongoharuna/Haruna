package com.sentongoharuna.pulse

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * A deliberately small navigator.  It lives inside each existing bottom deck
 * instead of wrapping the camera preview in a pager, so Main and Live keep
 * their current CameraX lifecycle, gestures, controls and settings screens.
 */
object DevelopUgandaCameraModeNavigator {

    private data class Destination(
        val page: DevelopUgandaCameraPage,
        val label: String,
        val activity: Class<out Activity>
    )

    private val destinations =
        listOf(
            Destination(
                DevelopUgandaCameraPage.MAIN,
                "MAIN",
                DevelopUgandaAllProCameraActivity::class.java
            ),
            Destination(
                DevelopUgandaCameraPage.LIVE,
                "LIVE",
                DevelopUgandaLiveActivity::class.java
            ),
            Destination(
                DevelopUgandaCameraPage.TIKTOK,
                "TIKTOK",
                DevelopUgandaTikTokCameraActivity::class.java
            ),
            Destination(
                DevelopUgandaCameraPage.STATUS,
                "STATUS",
                DevelopUgandaStatusCameraActivity::class.java
            ),
            Destination(
                DevelopUgandaCameraPage.INTERVIEW,
                "INTERVIEW",
                DevelopUgandaInterviewCameraActivity::class.java
            )
        )

    fun create(
        activity: Activity,
        current: DevelopUgandaCameraPage,
        dp: (Int) -> Int,
        canNavigate: () -> Boolean
    ): View {
        val strip =
            LinearLayout(activity).apply {
                tag = "v281_five_mode_strip"
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                setPadding(0, dp(7), 0, 0)
            }

        fun navigateTo(index: Int) {
            if (!canNavigate()) {
                Toast.makeText(
                    activity,
                    "Stop recording before changing camera mode",
                    Toast.LENGTH_SHORT
                ).show()
                return
            }

            val destination = destinations.getOrNull(index) ?: return
            if (destination.page == current) return

            activity.startActivity(
                Intent(activity, destination.activity).apply {
                    addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT)
                }
            )
            activity.finish()
        }

        destinations.forEachIndexed { index, destination ->
            var downX = 0f
            val active = destination.page == current
            val label =
                TextView(activity).apply {
                    text = destination.label
                    gravity = Gravity.CENTER
                    textSize = 9f
                    typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
                    setTextColor(if (active) Color.WHITE else 0xFFAEB7C7.toInt())
                    alpha = if (active) 1f else 0.76f
                    setPadding(dp(2), dp(7), dp(2), dp(7))
                    background = GradientDrawable().apply {
                        cornerRadius = dp(9).toFloat()
                        setColor(
                            if (active) 0xFF204A58.toInt() else 0x2AFFFFFF
                        )
                    }
                    setOnClickListener { navigateTo(index) }
                    setOnTouchListener { _, event ->
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                downX = event.rawX
                                false
                            }

                            MotionEvent.ACTION_UP -> {
                                val distance = event.rawX - downX
                                if (abs(distance) >= dp(44)) {
                                    val currentIndex =
                                        destinations.indexOfFirst { it.page == current }
                                    val next =
                                        if (distance < 0f) currentIndex + 1 else currentIndex - 1
                                    navigateTo(next.coerceIn(0, destinations.lastIndex))
                                    true
                                } else {
                                    false
                                }
                            }

                            else -> false
                        }
                    }
                }

            strip.addView(
                label,
                LinearLayout.LayoutParams(
                    0,
                    dp(30),
                    1f
                ).apply {
                    if (index > 0) marginStart = dp(3)
                }
            )
        }

        return strip
    }
}
