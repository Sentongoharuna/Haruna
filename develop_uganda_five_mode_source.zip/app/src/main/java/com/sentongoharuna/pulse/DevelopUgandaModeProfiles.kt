package com.sentongoharuna.pulse

/**
 * Additive profiles for the three new camera pages.  Existing experiences are
 * deliberately not represented here, so their defaults and settings stay
 * exactly as they were before the five-page strip was added.
 */
enum class DevelopUgandaCameraPage {
    MAIN,
    LIVE,
    TIKTOK,
    STATUS,
    INTERVIEW
}

enum class DevelopUgandaDeliveryProfile {
    NONE,
    TIKTOK_UPLOAD,
    WHATSAPP_STATUS,
    INTERVIEW_DUAL
}

data class DevelopUgandaModeProfile(
    val page: DevelopUgandaCameraPage,
    val experienceId: String,
    val displayName: String,
    val bestFor: String,
    val instruction: String,
    val accentColor: Int,
    val qualityName: String,
    val sceneName: String,
    val lookName: String,
    val frameRate: Int,
    val targetBitrateBps: Int,
    val deliveryProfile: DevelopUgandaDeliveryProfile,
    val portraitOutput: Boolean = true
)

object DevelopUgandaModeProfiles {

    val tikTok =
        DevelopUgandaModeProfile(
            page = DevelopUgandaCameraPage.TIKTOK,
            experienceId = "V281_TIKTOK",
            displayName = "TIKTOK CAM",
            bestFor = "TIKTOK / REELS / SHORTS",
            instruction = "9:16 • 1080 • 60 FPS • CLEAN MASTER + UPLOAD COPY",
            accentColor = 0xFF62D8C9.toInt(),
            qualityName = "SOCIAL 60",
            sceneName = "REPORTER",
            lookName = "NATURAL",
            frameRate = 60,
            targetBitrateBps = 18_000_000,
            deliveryProfile = DevelopUgandaDeliveryProfile.TIKTOK_UPLOAD
        )

    val status =
        DevelopUgandaModeProfile(
            page = DevelopUgandaCameraPage.STATUS,
            experienceId = "V281_STATUS",
            displayName = "STATUS CAM",
            bestFor = "WHATSAPP STATUS",
            instruction = "9:16 • 1080 • 30 FPS • CLEAN MASTER + STATUS COPY",
            accentColor = 0xFF83B995.toInt(),
            qualityName = "SOCIAL FHD",
            sceneName = "REPORTER",
            lookName = "NATURAL",
            frameRate = 30,
            targetBitrateBps = 7_000_000,
            deliveryProfile = DevelopUgandaDeliveryProfile.WHATSAPP_STATUS
        )

    val interview =
        DevelopUgandaModeProfile(
            page = DevelopUgandaCameraPage.INTERVIEW,
            experienceId = "V281_INTERVIEW",
            displayName = "INTERVIEW CAM",
            bestFor = "SINGLE-SUBJECT INTERVIEWS",
            instruction = "MEDIUM CLOSE-UP • ON-DEVICE OBSERVATION HUD • CLEAN MASTER",
            accentColor = 0xFFAEBDEB.toInt(),
            qualityName = "SOCIAL FHD",
            sceneName = "INTERVIEW",
            lookName = "CLEAN",
            frameRate = 30,
            targetBitrateBps = 18_000_000,
            deliveryProfile = DevelopUgandaDeliveryProfile.INTERVIEW_DUAL
        )

    fun forExperience(experienceId: String): DevelopUgandaModeProfile? {
        return when (experienceId) {
            tikTok.experienceId -> tikTok
            status.experienceId -> status
            interview.experienceId -> interview
            else -> null
        }
    }
}
