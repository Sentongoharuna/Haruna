R6 CAMERA 9011 SOURCE PATCH PACK

Upload tools/apply_r6_changes.py and .github/workflows/00-R6-CAMERA-9011-SOURCE-LOCKED.yml to the SAME paths in the Haruna repository.

This pack is SOURCE PATCH CODE, not the complete reconstructed Android project. It requires the original R6 S5 02A workflow already in that repository, and stops if the approved R6 baseline is unavailable. It does not import FIVEMODS 10/11/12 or claim unimplemented AI features.
