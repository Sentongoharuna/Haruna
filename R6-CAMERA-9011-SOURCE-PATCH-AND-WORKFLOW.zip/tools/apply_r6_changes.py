#!/usr/bin/env python3
"""Apply R6-only camera interface cleanup to the restored approved source.
Does not replace recording engine, camera modes, or baseline."""
from pathlib import Path
import re
root=Path("app/src/main/java/com/sentongoharuna/pulse")
nav=root/"DevelopUgandaCameraModeNavigator.kt"
cam=root/"DevelopUgandaCameraActivity.kt"
assert nav.is_file() and cam.is_file(), "R6 camera source is missing"
n=nav.read_text()
assert "R5: five mode icons at the extreme safe bottom" in n, "Not approved R6 navigator"
assert "translationY = dp(10).toFloat()" in n, "R6 bottom positioning missing"
assert "surfaceScrim(240)" not in n, "Old opaque navbar detected"
s=cam.read_text()
assert "r6ApplyRecordSurface(r6RecordingVisualActive)" in s, "Approved R6 record UI absent"
# No blind substitutions: stop rather than remove unrelated controls.
print("R6 source identity verified. Existing transparent bottom icons retained.")
print("Side button removal and AI features are not claimed by this patch.")
