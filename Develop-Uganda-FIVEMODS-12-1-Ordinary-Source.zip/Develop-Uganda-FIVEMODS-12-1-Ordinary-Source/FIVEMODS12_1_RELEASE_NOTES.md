# FIVEMODS 12.1 — Field Ready

Package: `com.sentongoharuna.pulse`  
Version: `285.00-fivemods12.1-field-reliability-assembly`

- Repairs the LIVE preference crash and migrates legacy wrong-typed values on launch.
- Guards every SharedPreferences typed read and records type metadata without values or stream keys.
- Measures free space on the resolved recording volume and separates storage measurement from bitrate availability.
- Allows MODERATE thermal and all UNKNOWN preflight states; only measured critical conditions refuse REC.
- Requires an explicit START ANYWAY for measured warning thresholds and records the exact override reason in the take sidecar.
- Makes the FIVEMODS 12 status strip the sole owner of the seven camera status fields.
- Routes dialog actions through the active mode accent and applies the compact instrument type scale.
- Removes legacy depth shadows, animated glow rings, positive elevation and shader gradients; state now uses flat outline and colour.
- Adds ordered multi-clip BRAND assembly with mark-derived cuts and confirmed-caption retiming through the existing Media3 exporter.
- Applies shared logo, lower third and end card identity to BRAND outputs only. CLEAN masters remain untouched.
- Replaces the embedded overlay build with ordinary committed source, explicit KVM, and a boot-gated emulator suite.

Forensic note: the on-device LIVE crash reaches the first Boolean read at
`develop_uganda_live_camera/audio` while a legacy String value is stored. The
retained FIVEMODS 11 and 12 archives already read that key as Boolean, so the
exact older writer build is not present in the repository and is not guessed.
