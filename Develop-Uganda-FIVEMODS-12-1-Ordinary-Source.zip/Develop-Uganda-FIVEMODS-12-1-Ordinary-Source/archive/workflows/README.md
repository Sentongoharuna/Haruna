# Archived reconstruction workflows

The files placed in this directory by the one-time migration workflow are the
disabled historical build chain. Each filename keeps its original workflow
name and gains a `.disabled` suffix so GitHub Actions cannot execute it.

They are retained as provenance for the former reconstruction stages:

- source archive unpacking;
- FIVEMODS 8 snapshot restoration;
- FIVEMODS 9 Interview hotfix;
- Status Policy repair;
- FIX1 five-mode presentation merge;
- FIVEMODS 10 exposure repair; and
- broadcast presentation and reviewed-caption overlay.

The active build no longer executes any of those transformations. It compiles
the committed `app/src/main` tree directly and runs their protection checks as
source-contract tests.

